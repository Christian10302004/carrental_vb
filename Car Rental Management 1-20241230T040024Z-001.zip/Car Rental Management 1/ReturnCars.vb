﻿Imports MySql.Data.MySqlClient

Public Class ReturnCars
    Private fees As Decimal = 0 ' To store the base fees from rent_info
    Private dailyRate As Decimal = 0 ' To store the car's daily rate from cars_info
    Private originalReturnDate As DateTime ' To store the original return date from rent_info

    Private Sub ReturnCars_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadRentData()
        LoadReturnedData() ' Load returned data to keep the view updated
        rentlistview.FullRowSelect = True
        rentlistview.View = View.Details
        AdjustListViewColumns()
        AdjustListViewColumns1()
        returnedlistview.FullRowSelect = True
        rentlistview.View = View.Details
    End Sub

    Private Sub LoadReturnedData()
        ' Clear any existing items in the returnedlistview
        returnedlistview.Items.Clear()

        ' Database connection and query to fetch return_info data
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query As String = "SELECT * FROM return_info"
                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim item As New ListViewItem(reader("returnid").ToString())
                            item.SubItems.Add(reader("regnumber").ToString())
                            item.SubItems.Add(reader("customername").ToString())

                            ' Format the return date to display only date without time
                            Dim returnDate As DateTime = DateTime.Parse(reader("returndate").ToString())
                            item.SubItems.Add(returnDate.ToString("dd/MM/yyyy")) ' Format the return date
                            item.SubItems.Add(reader("delay").ToString())
                            item.SubItems.Add(reader("fines").ToString())
                            item.SubItems.Add(reader("remarks").ToString())
                            item.SubItems.Add(reader("total").ToString())
                            returnedlistview.Items.Add(item)
                        End While
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("An error occurred while loading return data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub
    Private Sub ReturnCars_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        ' Re-adjust columns whenever the form is resized
        AdjustListViewColumns()
    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If rentlistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = rentlistview.ClientSize.Width
            Dim columnCount As Integer = rentlistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In rentlistview.Columns
                column.Width = columnWidth
            Next
        End If

        If returnedlistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = returnedlistview.ClientSize.Width
            Dim columnCount As Integer = returnedlistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In returnedlistview.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub

    Private Sub AdjustListViewColumns1()
        ' Ensure the ListView is populated before adjusting
        If returnedlistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = returnedlistview.ClientSize.Width
            Dim columnCount As Integer = returnedlistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In returnedlistview.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub

    Private Sub LoadRentData()
        ' Clear any existing items in the ListView
        rentlistview.Items.Clear()

        ' Database connection and query to fetch rent_info data
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query As String = "SELECT * FROM rent_info"
                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim item As New ListViewItem(reader("rentid").ToString())
                            item.SubItems.Add(reader("regnumber").ToString())
                            item.SubItems.Add(reader("customerid").ToString())
                            item.SubItems.Add(reader("customername").ToString())
                            item.SubItems.Add(reader("rentdate").ToString())
                            item.SubItems.Add(reader("returndate").ToString()) ' Return date from rent_info
                            item.SubItems.Add(reader("address").ToString())
                            item.SubItems.Add(reader("fees").ToString())
                            rentlistview.Items.Add(item)
                        End While
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("An error occurred while loading rent data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' When an item is selected in rentlistview
    Private Sub rentlistview_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rentlistview.SelectedIndexChanged
        If rentlistview.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = rentlistview.SelectedItems(0)

            ' Populate regnumberbox and customerbox with the selected item's data
            regnumberbox.Text = selectedItem.SubItems(1).Text ' regnumber is in the second column
            customerbox.Text = selectedItem.SubItems(3).Text  ' customername is in the fourth column

            ' Store the original return date and fees for later calculations
            originalReturnDate = DateTime.Parse(selectedItem.SubItems(5).Text) ' returndate column from rent_info
            fees = Decimal.Parse(selectedItem.SubItems(7).Text) ' fees column

            ' Now get the daily rate from cars_info based on the regnumber
            Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                Try
                    connection.Open()
                    Dim query As String = "SELECT price FROM cars_info WHERE regnumber = @regnumber"
                    Using command As New MySqlCommand(query, connection)
                        command.Parameters.AddWithValue("@regnumber", regnumberbox.Text)
                        Dim result As Object = command.ExecuteScalar()
                        If result IsNot Nothing Then
                            dailyRate = Decimal.Parse(result.ToString())
                        End If
                    End Using
                Catch ex As Exception
                    MessageBox.Show("Error fetching car price: " & ex.Message)
                End Try
            End Using

            ' Calculate the total immediately upon selection change
            CalculateTotal()
        End If
    End Sub

    ' Calculate the total based on delay, fines, and the car's daily rate
    Private Sub CalculateTotal()
        Dim delay As Integer = 0
        Dim fines As Decimal = 0

        ' Get values from delaybox and finesbox
        If Integer.TryParse(delaybox.Text, delay) Then
            delay = Integer.Parse(delaybox.Text)
        End If

        If Decimal.TryParse(finesbox.Text, fines) Then
            fines = Decimal.Parse(finesbox.Text)
        End If

        ' Calculate the return date based on the original return date + delay
        Dim returnDate As DateTime = originalReturnDate.AddDays(delay)

        ' Calculate the total
        Dim total As Decimal = fees + (dailyRate * delay) + fines

        ' Display the calculated total in totalbox
        totalbox.Text = total.ToString("0.00")
    End Sub

    ' Event handler for delaybox text change
    Private Sub delaybox_TextChanged(sender As Object, e As EventArgs) Handles delaybox.TextChanged
        ' Recalculate the total whenever the delay is changed
        CalculateTotal()
    End Sub

    ' Event handler for finesbox text change
    Private Sub finesbox_TextChanged(sender As Object, e As EventArgs) Handles finesbox.TextChanged
        ' Recalculate the total whenever the fines is changed
        CalculateTotal()
    End Sub

    Private Sub addbtn4_Click(sender As Object, e As EventArgs) Handles addbtn4.Click
        ' Check if a car is selected in rentlistview
        If rentlistview.SelectedItems.Count = 0 Then
            MessageBox.Show("Please choose a car to return.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the function without proceeding further
        End If

        ' Get values from textboxes
        Dim regnumber As String = regnumberbox.Text
        Dim customerName As String = customerbox.Text
        Dim delay As Integer = 0
        Dim fines As Decimal = 0
        Dim total As Decimal
        Dim remarks As String = "No Remarks" ' Default remarks if not provided

        ' Get values from delaybox and finesbox
        If Integer.TryParse(delaybox.Text, delay) Then
            delay = Integer.Parse(delaybox.Text)
        End If

        If Decimal.TryParse(finesbox.Text, fines) Then
            fines = Decimal.Parse(finesbox.Text)
        End If

        ' Use remarks from the textbox if provided, otherwise use "No Remarks"
        If Not String.IsNullOrEmpty(remarksbox.Text) Then
            remarks = remarksbox.Text
        End If

        ' Calculate the total
        total = fees + (dailyRate * delay) + fines

        ' Insert data into return_info table
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()

                ' Insert data into return_info table
                Dim query As String = "INSERT INTO return_info (regnumber, customername, returndate, delay, fines, remarks, total) " &
                                      "VALUES (@regnumber, @customername, @returndate, @delay, @fines, @remarks, @total)"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.Parameters.AddWithValue("@customername", customerName)
                    command.Parameters.AddWithValue("@returndate", originalReturnDate.AddDays(delay))
                    command.Parameters.AddWithValue("@delay", delay)
                    command.Parameters.AddWithValue("@fines", fines)
                    command.Parameters.AddWithValue("@remarks", remarks)
                    command.Parameters.AddWithValue("@total", total)
                    command.ExecuteNonQuery()
                End Using

                ' Delete the record from rent_info table
                query = "DELETE FROM rent_info WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.ExecuteNonQuery()
                End Using

                ' Refresh the rentlistview and returnedlistview
                LoadRentData()
                LoadReturnedData()

                ' Reset the form fields
                Clearfields()
            Catch ex As Exception
                MessageBox.Show("An error occurred while returning the car: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub




    ' Clear form fields
    Private Sub clearbtn4_Click(sender As Object, e As EventArgs) Handles clearbtn4.Click
        regnumberbox.Clear()
        customerbox.Clear()
        delaybox.Clear()
        finesbox.Clear()
        remarksbox.Clear()
        totalbox.Clear()
    End Sub

    Private Sub Clearfields()
        regnumberbox.Clear()
        customerbox.Clear()
        delaybox.Clear()
        finesbox.Clear()
        remarksbox.Clear()
        totalbox.Clear()
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Rent.Show()
        Close()
    End Sub

    Private Sub customerslbl_Click(sender As Object, e As EventArgs) Handles customerslbl.Click
        Customer.ShowDialog()
        Close()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Form2.Show()
        Close()
    End Sub
    Private Sub returnedlistview_SelectedIndexChanged(sender As Object, e As EventArgs) Handles returnedlistview.SelectedIndexChanged
        ' Check if an item is selected in the returnedlistview
        If returnedlistview.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = returnedlistview.SelectedItems(0)
            Dim regnumber As String = selectedItem.SubItems(1).Text ' Registration number is in the second column

            ' Check if the car is already available
            Dim isAvailable As Boolean = False
            Dim isInRent As Boolean = False
            Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                Try
                    connection.Open()

                    ' Check if the car is already available
                    Dim query1 As String = "SELECT available FROM cars_info WHERE regnumber = @regnumber"
                    Using command1 As New MySqlCommand(query1, connection)
                        command1.Parameters.AddWithValue("@regnumber", regnumber)
                        Dim result As Object = command1.ExecuteScalar()
                        If result IsNot Nothing AndAlso result.ToString() = "YES" Then
                            isAvailable = True
                        End If
                    End Using

                    ' Check if the car is still in rentlistview
                    Dim query2 As String = "SELECT COUNT(*) FROM rent_info WHERE regnumber = @regnumber"
                    Using command2 As New MySqlCommand(query2, connection)
                        command2.Parameters.AddWithValue("@regnumber", regnumber)
                        Dim result As Integer = Convert.ToInt32(command2.ExecuteScalar())
                        If result > 0 Then
                            isInRent = True
                        End If
                    End Using

                    ' Handle cases
                    If isInRent Then
                        MessageBox.Show("This car is currently rented and cannot be marked as available.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return
                    End If

                    If isAvailable Then
                        MessageBox.Show("This car is already marked as available.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Return
                    End If

                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End Try
            End Using

            ' Prompt the user to confirm making the car available
            Dim resultDialog As DialogResult = MessageBox.Show("Do you want this car to be available?", "Confirm Availability", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If resultDialog = DialogResult.Yes Then
                ' Update the 'available' status in the cars_info table to "YES"
                Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    Try
                        connection.Open()
                        Dim query As String = "UPDATE cars_info SET available = 'YES' WHERE regnumber = @regnumber"
                        Using command As New MySqlCommand(query, connection)
                            command.Parameters.AddWithValue("@regnumber", regnumber)
                            command.ExecuteNonQuery()
                        End Using
                        MessageBox.Show("The car has been marked as available.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Catch ex As Exception
                        MessageBox.Show("An error occurred while updating the car's availability: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            Else
                ' The user chose No
                MessageBox.Show("The car's availability was not changed.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
    End Sub

End Class
