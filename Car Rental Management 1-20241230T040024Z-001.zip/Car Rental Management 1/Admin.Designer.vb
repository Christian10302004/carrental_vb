﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel6 = New TableLayoutPanel()
        backbtn = New Button()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel7 = New TableLayoutPanel()
        customerslbl = New Label()
        PictureBox5 = New PictureBox()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        TableLayoutPanel9 = New TableLayoutPanel()
        TableLayoutPanel16 = New TableLayoutPanel()
        Label13 = New Label()
        gendercbb = New ComboBox()
        TableLayoutPanel15 = New TableLayoutPanel()
        address = New TextBox()
        Label10 = New Label()
        TableLayoutPanel14 = New TableLayoutPanel()
        Label9 = New Label()
        age = New TextBox()
        TableLayoutPanel12 = New TableLayoutPanel()
        lastname = New TextBox()
        Label8 = New Label()
        TableLayoutPanel11 = New TableLayoutPanel()
        Label4 = New Label()
        firstname = New TextBox()
        TableLayoutPanel10 = New TableLayoutPanel()
        middlename = New TextBox()
        Label7 = New Label()
        TableLayoutPanel17 = New TableLayoutPanel()
        addbtn = New Button()
        clearbtn = New Button()
        deletebtn = New Button()
        editbtn = New Button()
        TableLayoutPanel18 = New TableLayoutPanel()
        Label14 = New Label()
        employeeslistview = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        ColumnHeader6 = New ColumnHeader()
        ColumnHeader7 = New ColumnHeader()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel6.SuspendLayout()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel7.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel9.SuspendLayout()
        TableLayoutPanel16.SuspendLayout()
        TableLayoutPanel15.SuspendLayout()
        TableLayoutPanel14.SuspendLayout()
        TableLayoutPanel12.SuspendLayout()
        TableLayoutPanel11.SuspendLayout()
        TableLayoutPanel10.SuspendLayout()
        TableLayoutPanel17.SuspendLayout()
        TableLayoutPanel18.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel9, 0, 2)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel17, 0, 3)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel18, 0, 4)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 5
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 8F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 9F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 26F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 47F))
        TableLayoutPanel1.Size = New Size(884, 591)
        TableLayoutPanel1.TabIndex = 2
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.BackColor = Color.White
        TableLayoutPanel2.ColumnCount = 3
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 5F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 85F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 10F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 0)
        TableLayoutPanel2.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel2.Controls.Add(TableLayoutPanel6, 2, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 3)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(878, 41)
        TableLayoutPanel2.TabIndex = 5
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(46, 8)
        Label2.Name = "Label2"
        Label2.Size = New Size(122, 25)
        Label2.TabIndex = 21
        Label2.Text = "CAR RENTAL"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(7, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 32)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel6
        ' 
        TableLayoutPanel6.ColumnCount = 1
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Controls.Add(backbtn, 0, 0)
        TableLayoutPanel6.Dock = DockStyle.Fill
        TableLayoutPanel6.Location = New Point(792, 3)
        TableLayoutPanel6.Name = "TableLayoutPanel6"
        TableLayoutPanel6.RowCount = 1
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Size = New Size(83, 35)
        TableLayoutPanel6.TabIndex = 22
        ' 
        ' backbtn
        ' 
        backbtn.Dock = DockStyle.Fill
        backbtn.Location = New Point(3, 3)
        backbtn.Name = "backbtn"
        backbtn.Size = New Size(77, 29)
        backbtn.TabIndex = 0
        backbtn.Text = "BACK"
        backbtn.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.BackColor = Color.White
        TableLayoutPanel3.ColumnCount = 2
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 33.3333321F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 33.3333321F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel7, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 50)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(878, 47)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 2
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.Controls.Add(customerslbl, 0, 0)
        TableLayoutPanel7.Controls.Add(PictureBox5, 0, 0)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(442, 3)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 1
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel7.Size = New Size(433, 41)
        TableLayoutPanel7.TabIndex = 2
        ' 
        ' customerslbl
        ' 
        customerslbl.Anchor = AnchorStyles.Left
        customerslbl.AutoSize = True
        customerslbl.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        customerslbl.Location = New Point(219, 8)
        customerslbl.Name = "customerslbl"
        customerslbl.Size = New Size(110, 25)
        customerslbl.TabIndex = 26
        customerslbl.Text = "ACCOUNTS"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Right
        PictureBox5.Image = My.Resources.Resources.id_card__1_
        PictureBox5.Location = New Point(180, 4)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 33)
        PictureBox5.TabIndex = 25
        PictureBox5.TabStop = False
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel4.Controls.Add(Label3, 1, 0)
        TableLayoutPanel4.Dock = DockStyle.Fill
        TableLayoutPanel4.Location = New Point(3, 3)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Size = New Size(433, 41)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.employees__1_
        PictureBox3.Location = New Point(180, 4)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(33, 33)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Left
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(219, 8)
        Label3.Name = "Label3"
        Label3.Size = New Size(114, 25)
        Label3.TabIndex = 21
        Label3.Text = "EMPLOYEES"
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel9.ColumnCount = 3
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.Controls.Add(TableLayoutPanel16, 2, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel15, 1, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel14, 0, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel12, 2, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel11, 0, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel10, 1, 0)
        TableLayoutPanel9.Dock = DockStyle.Fill
        TableLayoutPanel9.Location = New Point(3, 103)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 2
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.Size = New Size(878, 147)
        TableLayoutPanel9.TabIndex = 2
        ' 
        ' TableLayoutPanel16
        ' 
        TableLayoutPanel16.BackColor = Color.White
        TableLayoutPanel16.ColumnCount = 1
        TableLayoutPanel16.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Controls.Add(Label13, 0, 0)
        TableLayoutPanel16.Controls.Add(gendercbb, 0, 1)
        TableLayoutPanel16.Dock = DockStyle.Fill
        TableLayoutPanel16.Location = New Point(573, 76)
        TableLayoutPanel16.Name = "TableLayoutPanel16"
        TableLayoutPanel16.RowCount = 2
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Size = New Size(302, 68)
        TableLayoutPanel16.TabIndex = 6
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Bottom
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(108, 9)
        Label13.Name = "Label13"
        Label13.Size = New Size(86, 25)
        Label13.TabIndex = 17
        Label13.Text = "GENDER"
        ' 
        ' gendercbb
        ' 
        gendercbb.Anchor = AnchorStyles.Top
        gendercbb.DropDownStyle = ComboBoxStyle.DropDownList
        gendercbb.Font = New Font("Segoe UI", 12F)
        gendercbb.FormattingEnabled = True
        gendercbb.Location = New Point(86, 37)
        gendercbb.Name = "gendercbb"
        gendercbb.Size = New Size(130, 29)
        gendercbb.TabIndex = 6
        ' 
        ' TableLayoutPanel15
        ' 
        TableLayoutPanel15.BackColor = Color.White
        TableLayoutPanel15.ColumnCount = 1
        TableLayoutPanel15.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Controls.Add(address, 0, 1)
        TableLayoutPanel15.Controls.Add(Label10, 0, 0)
        TableLayoutPanel15.Dock = DockStyle.Fill
        TableLayoutPanel15.Location = New Point(310, 76)
        TableLayoutPanel15.Name = "TableLayoutPanel15"
        TableLayoutPanel15.RowCount = 2
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Size = New Size(257, 68)
        TableLayoutPanel15.TabIndex = 5
        ' 
        ' address
        ' 
        address.Anchor = AnchorStyles.Top
        address.Font = New Font("Segoe UI", 12F)
        address.Location = New Point(63, 37)
        address.Name = "address"
        address.Size = New Size(130, 29)
        address.TabIndex = 5
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Bottom
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(81, 9)
        Label10.Name = "Label10"
        Label10.Size = New Size(95, 25)
        Label10.TabIndex = 10
        Label10.Text = "ADDRESS"
        ' 
        ' TableLayoutPanel14
        ' 
        TableLayoutPanel14.BackColor = Color.White
        TableLayoutPanel14.ColumnCount = 1
        TableLayoutPanel14.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Controls.Add(Label9, 0, 0)
        TableLayoutPanel14.Controls.Add(age, 0, 1)
        TableLayoutPanel14.Dock = DockStyle.Fill
        TableLayoutPanel14.Location = New Point(3, 76)
        TableLayoutPanel14.Name = "TableLayoutPanel14"
        TableLayoutPanel14.RowCount = 2
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Size = New Size(301, 68)
        TableLayoutPanel14.TabIndex = 4
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Bottom
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(126, 9)
        Label9.Name = "Label9"
        Label9.Size = New Size(48, 25)
        Label9.TabIndex = 16
        Label9.Text = "AGE"
        ' 
        ' age
        ' 
        age.Anchor = AnchorStyles.Top
        age.Font = New Font("Segoe UI", 12F)
        age.Location = New Point(85, 37)
        age.Name = "age"
        age.Size = New Size(130, 29)
        age.TabIndex = 4
        ' 
        ' TableLayoutPanel12
        ' 
        TableLayoutPanel12.BackColor = Color.White
        TableLayoutPanel12.ColumnCount = 1
        TableLayoutPanel12.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Controls.Add(lastname, 0, 1)
        TableLayoutPanel12.Controls.Add(Label8, 0, 0)
        TableLayoutPanel12.Dock = DockStyle.Fill
        TableLayoutPanel12.Location = New Point(573, 3)
        TableLayoutPanel12.Name = "TableLayoutPanel12"
        TableLayoutPanel12.RowCount = 2
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Size = New Size(302, 67)
        TableLayoutPanel12.TabIndex = 3
        ' 
        ' lastname
        ' 
        lastname.Anchor = AnchorStyles.Top
        lastname.Font = New Font("Segoe UI", 12F)
        lastname.Location = New Point(86, 36)
        lastname.Name = "lastname"
        lastname.Size = New Size(130, 29)
        lastname.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Bottom
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(93, 8)
        Label8.Name = "Label8"
        Label8.Size = New Size(115, 25)
        Label8.TabIndex = 8
        Label8.Text = "LAST NAME"
        ' 
        ' TableLayoutPanel11
        ' 
        TableLayoutPanel11.BackColor = Color.White
        TableLayoutPanel11.ColumnCount = 1
        TableLayoutPanel11.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Controls.Add(Label4, 0, 0)
        TableLayoutPanel11.Controls.Add(firstname, 0, 1)
        TableLayoutPanel11.Dock = DockStyle.Fill
        TableLayoutPanel11.Location = New Point(3, 3)
        TableLayoutPanel11.Name = "TableLayoutPanel11"
        TableLayoutPanel11.RowCount = 2
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Size = New Size(301, 67)
        TableLayoutPanel11.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(90, 8)
        Label4.Name = "Label4"
        Label4.Size = New Size(121, 25)
        Label4.TabIndex = 6
        Label4.Text = "FIRST NAME"
        ' 
        ' firstname
        ' 
        firstname.Anchor = AnchorStyles.Top
        firstname.Font = New Font("Segoe UI", 12F)
        firstname.Location = New Point(85, 36)
        firstname.Name = "firstname"
        firstname.Size = New Size(130, 29)
        firstname.TabIndex = 0
        ' 
        ' TableLayoutPanel10
        ' 
        TableLayoutPanel10.BackColor = Color.White
        TableLayoutPanel10.ColumnCount = 1
        TableLayoutPanel10.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Controls.Add(middlename, 0, 1)
        TableLayoutPanel10.Controls.Add(Label7, 0, 0)
        TableLayoutPanel10.Dock = DockStyle.Fill
        TableLayoutPanel10.Location = New Point(310, 3)
        TableLayoutPanel10.Name = "TableLayoutPanel10"
        TableLayoutPanel10.RowCount = 2
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Size = New Size(257, 67)
        TableLayoutPanel10.TabIndex = 2
        ' 
        ' middlename
        ' 
        middlename.Anchor = AnchorStyles.Top
        middlename.Font = New Font("Segoe UI", 12F)
        middlename.Location = New Point(63, 36)
        middlename.Name = "middlename"
        middlename.Size = New Size(130, 29)
        middlename.TabIndex = 8
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Bottom
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(56, 8)
        Label7.Name = "Label7"
        Label7.Size = New Size(144, 25)
        Label7.TabIndex = 7
        Label7.Text = "MIDDLE NAME"
        ' 
        ' TableLayoutPanel17
        ' 
        TableLayoutPanel17.BackColor = Color.White
        TableLayoutPanel17.ColumnCount = 4
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.Controls.Add(addbtn, 0, 0)
        TableLayoutPanel17.Controls.Add(clearbtn, 3, 0)
        TableLayoutPanel17.Controls.Add(deletebtn, 2, 0)
        TableLayoutPanel17.Controls.Add(editbtn, 1, 0)
        TableLayoutPanel17.Dock = DockStyle.Fill
        TableLayoutPanel17.Location = New Point(3, 256)
        TableLayoutPanel17.Name = "TableLayoutPanel17"
        TableLayoutPanel17.RowCount = 1
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel17.Size = New Size(878, 53)
        TableLayoutPanel17.TabIndex = 3
        ' 
        ' addbtn
        ' 
        addbtn.Anchor = AnchorStyles.Right
        addbtn.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        addbtn.Location = New Point(160, 11)
        addbtn.Name = "addbtn"
        addbtn.Size = New Size(100, 30)
        addbtn.TabIndex = 7
        addbtn.Text = "ADD"
        addbtn.TextAlign = ContentAlignment.TopCenter
        addbtn.UseVisualStyleBackColor = True
        ' 
        ' clearbtn
        ' 
        clearbtn.Anchor = AnchorStyles.Left
        clearbtn.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        clearbtn.Location = New Point(616, 11)
        clearbtn.Name = "clearbtn"
        clearbtn.Size = New Size(100, 30)
        clearbtn.TabIndex = 10
        clearbtn.Text = "CLEAR"
        clearbtn.TextAlign = ContentAlignment.TopCenter
        clearbtn.UseVisualStyleBackColor = True
        ' 
        ' deletebtn
        ' 
        deletebtn.Anchor = AnchorStyles.None
        deletebtn.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        deletebtn.Location = New Point(475, 11)
        deletebtn.Name = "deletebtn"
        deletebtn.Size = New Size(100, 30)
        deletebtn.TabIndex = 9
        deletebtn.Text = "DELETE"
        deletebtn.TextAlign = ContentAlignment.TopCenter
        deletebtn.UseVisualStyleBackColor = True
        ' 
        ' editbtn
        ' 
        editbtn.Anchor = AnchorStyles.None
        editbtn.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        editbtn.Location = New Point(300, 11)
        editbtn.Name = "editbtn"
        editbtn.Size = New Size(100, 30)
        editbtn.TabIndex = 8
        editbtn.Text = "EDIT"
        editbtn.TextAlign = ContentAlignment.TopCenter
        editbtn.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel18
        ' 
        TableLayoutPanel18.BackColor = Color.White
        TableLayoutPanel18.ColumnCount = 1
        TableLayoutPanel18.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel18.Controls.Add(Label14, 0, 0)
        TableLayoutPanel18.Controls.Add(employeeslistview, 0, 1)
        TableLayoutPanel18.Dock = DockStyle.Fill
        TableLayoutPanel18.Location = New Point(3, 315)
        TableLayoutPanel18.Name = "TableLayoutPanel18"
        TableLayoutPanel18.RowCount = 2
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 12F))
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 88F))
        TableLayoutPanel18.Size = New Size(878, 273)
        TableLayoutPanel18.TabIndex = 4
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.None
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(382, 3)
        Label14.Name = "Label14"
        Label14.Size = New Size(114, 25)
        Label14.TabIndex = 17
        Label14.Text = "EMPLOYEES"
        ' 
        ' employeeslistview
        ' 
        employeeslistview.BorderStyle = BorderStyle.FixedSingle
        employeeslistview.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5, ColumnHeader6, ColumnHeader7})
        employeeslistview.Dock = DockStyle.Fill
        employeeslistview.Font = New Font("Segoe UI", 11F)
        employeeslistview.GridLines = True
        employeeslistview.Location = New Point(3, 35)
        employeeslistview.Name = "employeeslistview"
        employeeslistview.Size = New Size(872, 235)
        employeeslistview.TabIndex = 11
        employeeslistview.UseCompatibleStateImageBehavior = False
        employeeslistview.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "EMPLOYEE ID"
        ColumnHeader1.Width = 100
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "FIRST NAME"
        ColumnHeader2.TextAlign = HorizontalAlignment.Center
        ColumnHeader2.Width = 150
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "MIDDLE NAME"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 150
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "LAST NAME"
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 100
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "AGE"
        ColumnHeader5.TextAlign = HorizontalAlignment.Center
        ColumnHeader5.Width = 110
        ' 
        ' ColumnHeader6
        ' 
        ColumnHeader6.Text = "ADDRESS"
        ColumnHeader6.TextAlign = HorizontalAlignment.Center
        ColumnHeader6.Width = 150
        ' 
        ' ColumnHeader7
        ' 
        ColumnHeader7.Text = "GENDER"
        ColumnHeader7.TextAlign = HorizontalAlignment.Center
        ColumnHeader7.Width = 130
        ' 
        ' Admin
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(884, 591)
        Controls.Add(TableLayoutPanel1)
        Name = "Admin"
        Text = "Admin"
        WindowState = FormWindowState.Maximized
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel6.ResumeLayout(False)
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel7.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel9.ResumeLayout(False)
        TableLayoutPanel16.ResumeLayout(False)
        TableLayoutPanel16.PerformLayout()
        TableLayoutPanel15.ResumeLayout(False)
        TableLayoutPanel15.PerformLayout()
        TableLayoutPanel14.ResumeLayout(False)
        TableLayoutPanel14.PerformLayout()
        TableLayoutPanel12.ResumeLayout(False)
        TableLayoutPanel12.PerformLayout()
        TableLayoutPanel11.ResumeLayout(False)
        TableLayoutPanel11.PerformLayout()
        TableLayoutPanel10.ResumeLayout(False)
        TableLayoutPanel10.PerformLayout()
        TableLayoutPanel17.ResumeLayout(False)
        TableLayoutPanel18.ResumeLayout(False)
        TableLayoutPanel18.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents customerslbl As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel16 As TableLayoutPanel
    Friend WithEvents Label13 As Label
    Friend WithEvents gendercbb As ComboBox
    Friend WithEvents TableLayoutPanel15 As TableLayoutPanel
    Friend WithEvents address As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TableLayoutPanel14 As TableLayoutPanel
    Friend WithEvents Label9 As Label
    Friend WithEvents age As TextBox
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents lastname As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents firstname As TextBox
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents Label7 As Label
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents addbtn As Button
    Friend WithEvents clearbtn As Button
    Friend WithEvents deletebtn As Button
    Friend WithEvents editbtn As Button
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents Label14 As Label
    Friend WithEvents employeeslistview As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents ColumnHeader7 As ColumnHeader
    Friend WithEvents middlename As TextBox
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents backbtn As Button
End Class
