﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        db_connector() ' Establish a connection to the database

    End Sub

    Private Sub adminlog_Click_1(sender As Object, e As EventArgs) Handles adminlog.Click
        Dim username = admintxt.Text
        Dim password = passtxt.Text

        ' Validate that no fields are left blank
        If String.IsNullOrWhiteSpace(username) OrElse String.IsNullOrWhiteSpace(password) Then
            MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the method if any field is empty
        End If

        ' Check credentials in the database
        Try
            ' Connection string
            Dim connectionString = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to check if the admin exists with the given username and password
                Dim query = "SELECT COUNT(*) FROM accounts_info WHERE username = @username AND password = @password"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@username", username)
                    command.Parameters.AddWithValue("@password", password)

                    ' Execute the query and get the result
                    Dim result = Convert.ToInt32(command.ExecuteScalar)

                    If result > 0 Then
                        ' Login successful
                        MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        ' Optionally, show the main admin dashboard form here
                        Dim body As New Form2
                        body.Show()
                        Hide()
                    Else
                        ' Login failed
                        MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while connecting to the database: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        AdminLogin.Show()
        Me.Hide()
    End Sub
End Class
