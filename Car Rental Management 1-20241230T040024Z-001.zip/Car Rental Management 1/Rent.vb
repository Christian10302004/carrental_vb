﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Imports ZstdSharp.Unsafe

Public Class Rent
    Private customerNames As New Dictionary(Of String, String)

    Private Sub RentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set up ListView
        rentlistview.View = View.Details
        rentlistview.FullRowSelect = True
        AddHandler Label3.Click, AddressOf Label3_Click
        AddHandler customerslbl.Click, AddressOf customerslbl_Click_1
        AddHandler rentlistview.SelectedIndexChanged, AddressOf rentlistview_SelectedIndexChanged

        AdjustListViewColumns()
        ' Load ComboBox data and rent data
        LoadAvailableCars()
        LoadCustomers()
        LoadRentData()
        DateTimePicker1.Format = DateTimePickerFormat.Short ' Use Short Date Format (e.g., MM/dd/yyyy)
        DateTimePicker2.Format = DateTimePickerFormat.Short

        DateTimePicker1.Value = DateTime.Now.Date ' Rent Date
        DateTimePicker2.Value = DateTime.Now.Date ' Return Date



        ' Inside your form's constructor or Load event
        AddHandler addbtn3.Click, AddressOf addbtn3_Click
        AddHandler editbtn3.Click, AddressOf editbtn3_Click
        AddHandler deletebtn3.Click, AddressOf deletebtn3_Click
        AddHandler clearbtn3.Click, AddressOf clearbtn3_Click
        feesbox.Text = "0"

    End Sub
    Private Sub Rent_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        ' Re-adjust columns whenever the form is resized
        AdjustListViewColumns()
    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If rentlistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = rentlistview.ClientSize.Width
            Dim columnCount As Integer = rentlistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In rentlistview.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub
    Private Sub LoadAvailableCars()
        ' Clear previous items from the ComboBox
        regcbb.Items.Clear()

        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                ' Adjust query to check for "YES" in available column
                Dim query As String = "SELECT regnumber FROM cars_info WHERE available = 'YES'"

                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()

                        While reader.Read()
                            regcbb.Items.Add(reader("regnumber").ToString())
                        End While
                    End Using
                End Using

            Catch ex As Exception
                MessageBox.Show("An error occurred while loading available cars: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub


    Private Sub LoadCustomers()
        ' Populate customercbb with customer IDs and names
        customercbb.Items.Clear()
        customerNames.Clear()

        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query As String = "SELECT customerid, CONCAT(firstname, ' ', lastname) AS fullname FROM customer_info"

                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim customerId = reader("customerid").ToString()
                            Dim customerName = reader("fullname").ToString()
                            customercbb.Items.Add(customerId)
                            customerNames(customerId) = customerName
                        End While
                    End Using
                End Using

            Catch ex As Exception
                MessageBox.Show("An error occurred while loading customers: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub LoadRentData()
        ' Load rent data into rentlistview
        rentlistview.Items.Clear()

        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query As String = "SELECT * FROM rent_info"

                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim item As New ListViewItem(reader("rentid").ToString())
                            item.SubItems.Add(reader("regnumber").ToString())
                            item.SubItems.Add(reader("customerid").ToString())
                            item.SubItems.Add(reader("customername").ToString())
                            item.SubItems.Add(reader("rentdate").ToString())
                            item.SubItems.Add(reader("returndate").ToString())
                            item.SubItems.Add(reader("address").ToString())
                            item.SubItems.Add(reader("fees").ToString())
                            rentlistview.Items.Add(item)
                        End While
                    End Using
                End Using

            Catch ex As Exception
                MessageBox.Show("An error occurred while loading rent data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub addbtn3_Click(sender As Object, e As EventArgs)
        ' Check if a car is selected in regcbb
        If regcbb.SelectedIndex = -1 Then
            MessageBox.Show("Please select a car to rent.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Gather form inputs
        Dim regnumber = regcbb.SelectedItem.ToString() ' Get the selected registration number
        Dim customerid = customercbb.Text
        Dim address = addressbox.Text
        Dim rentdate = DateTimePicker1.Value
        Dim returndate = DateTimePicker2.Value
        Dim fees As Decimal

        ' Validate inputs and rental dates
        If Not ValidateRentInputs(regnumber, customerid, address, rentdate, returndate, fees) Then Return

        If Not AddressContainsLetters(address) Then
            MessageBox.Show("The address must contain letters or a combination of letters and numbers.", "Invalid Address", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Calculate fees after validation
        CalculateFees(rentdate, returndate, fees)

        Dim customerName = If(customerNames.ContainsKey(customerid), customerNames(customerid), "")

        ' Insert rental data into the database
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()

                ' Insert rental record
                Dim query = "INSERT INTO rent_info (regnumber, customerid, customername, rentdate, returndate, address, fees) VALUES (@regnumber, @customerid, @customername, @rentdate, @returndate, @address, @fees)"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.Parameters.AddWithValue("@customerid", customerid)
                    command.Parameters.AddWithValue("@customername", customerName)
                    command.Parameters.AddWithValue("@rentdate", rentdate)
                    command.Parameters.AddWithValue("@returndate", returndate)
                    command.Parameters.AddWithValue("@address", address)
                    command.Parameters.AddWithValue("@fees", fees)
                    command.ExecuteNonQuery()
                End Using

                ' Update the availability of the car
                Dim updateQuery = "UPDATE cars_info SET available = 'NO' WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(updateQuery, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.ExecuteNonQuery()
                End Using

                ' Refresh data and clear fields
                LoadAvailableCars()
                LoadRentData()
                ClearFields()

                MessageBox.Show("Rental added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Catch ex As Exception
                MessageBox.Show("An error occurred while adding the rental: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Function ValidateRentInputs(regnumber As String, customerid As String, address As String, rentdate As DateTime, returndate As DateTime, ByRef fees As Decimal) As Boolean
        ' Check for blank fields
        If String.IsNullOrWhiteSpace(regnumber) Then
            MessageBox.Show("Please select a car to rent.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If String.IsNullOrWhiteSpace(customerid) OrElse String.IsNullOrWhiteSpace(address) Then
            MessageBox.Show("Please fill out all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validate that both rent date and return date are selected
        If rentdate = DateTime.MinValue OrElse returndate = DateTime.MinValue Then
            MessageBox.Show("Please set both the rent date and the return date.", "Date Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Ensure rent date is not in the past
        If rentdate.Date < DateTime.Today Then
            MessageBox.Show("The rent date cannot be in the past.", "Invalid Rent Date", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Ensure the return date is at least one day after the rent date
        If (returndate - rentdate).Days < 1 Then
            MessageBox.Show("The return date must be at least one day after the rent date.", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' If feesbox contains a valid number, assign it to the fees variable
        If Not Decimal.TryParse(feesbox.Text, fees) Then
            MessageBox.Show("Please enter a valid number for fees.", "Invalid Fees", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub CalculateFees(rentdate As DateTime, returndate As DateTime, ByRef fees As Decimal)
        ' Calculate rental days
        Dim days As Integer = (returndate - rentdate).Days
        If days < 1 Then
            MessageBox.Show("The return date must be at least one day after the rent date.", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim dailyPrice As Decimal

        ' Retrieve daily price for the selected car from the database
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query As String = "SELECT price FROM cars_info WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regcbb.Text)
                    Dim result = command.ExecuteScalar()

                    ' Ensure a price was retrieved and is valid
                    If result IsNot Nothing AndAlso Decimal.TryParse(result.ToString(), dailyPrice) Then
                        ' Price was successfully retrieved
                    Else
                        MessageBox.Show("Could not retrieve the price for the selected car. Please check the car information.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return
                    End If
                End Using
            Catch ex As Exception
                MessageBox.Show("An error occurred while retrieving the price: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End Try
        End Using

        ' Calculate the total rental fee based on the daily price
        fees = days * dailyPrice

        ' Add additional fees if entered
        Dim additionalFees As Decimal = 0
        If Decimal.TryParse(feesbox.Text, additionalFees) Then
            fees += additionalFees
        End If

        ' Display the calculated total fees in the feesbox
        feesbox.Text = fees.ToString("F2") ' Format to two decimal places
    End Sub


    Private Function AddressContainsLetters(address As String) As Boolean
        ' Use LINQ to check if any character in the address is a letter
        Return address.Any(Function(c) Char.IsLetter(c))
    End Function


    Private Sub editbtn3_Click(sender As Object, e As EventArgs)
        If rentlistview.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a rent record to edit.", "Edit Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim selectedItem = rentlistview.SelectedItems(0)
        Dim rentId = Convert.ToInt32(selectedItem.Text) ' Get the rent ID from the selected item
        Dim regNumber = regcbb.Text
        Dim customerId = customercbb.Text
        Dim customerName = If(customerNames.ContainsKey(customerId), customerNames(customerId), "")
        Dim rentDate = DateTimePicker1.Value
        Dim returnDate = DateTimePicker2.Value
        Dim address = addressbox.Text
        Dim fees As Decimal
        If Not AddressContainsLetters(address) Then
            MessageBox.Show("The address must contain letters or a combination of letters and numbers.", "Invalid Address", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If


        If Not Decimal.TryParse(feesbox.Text, fees) Then
            MessageBox.Show("Please enter a valid amount for fees.", "Invalid Fees", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Update the record in the database
        Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
            Try
                connection.Open()
                Dim query = "UPDATE rent_info SET regnumber = @regnumber, customerid = @customerid, customername = @customername, rentdate = @rentdate, returndate = @returndate, address = @address, fees = @fees WHERE rentid = @rentid"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regNumber)
                    command.Parameters.AddWithValue("@customerid", customerId)
                    command.Parameters.AddWithValue("@customername", customerName)
                    command.Parameters.AddWithValue("@rentdate", rentDate)
                    command.Parameters.AddWithValue("@returndate", returnDate)
                    command.Parameters.AddWithValue("@address", address)
                    command.Parameters.AddWithValue("@fees", fees)
                    command.Parameters.AddWithValue("@rentid", rentId)
                    command.ExecuteNonQuery()
                End Using
                ' Update the availability of the car
                Dim updateQuery = "UPDATE cars_info SET available = 'NO' WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(updateQuery, connection)
                    command.Parameters.AddWithValue("@regnumber", regNumber)
                    command.ExecuteNonQuery()
                End Using

                MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Refresh the ListView and available cars list
                LoadRentData()
                LoadAvailableCars()

                ClearFields() ' Clear the form fields after updating
            Catch ex As Exception
                MessageBox.Show("An error occurred while updating the record: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub deletebtn3_Click(sender As Object, e As EventArgs)
        If rentlistview.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a rent record to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim selectedItem = rentlistview.SelectedItems(0)
        Dim rentId = Convert.ToInt32(selectedItem.Text)
        Dim regNumber = selectedItem.SubItems(1).Text ' Get the regnumber from the selected item

        If MessageBox.Show("Are you sure you want to delete this record?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Using connection As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                connection.Open()
                ' Delete the rent record
                Dim query = "DELETE FROM rent_info WHERE rentid = @rentid"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@rentid", rentId)
                    command.ExecuteNonQuery()
                End Using

                ' Update the availability of the car
                Dim updateQuery = "UPDATE cars_info SET available = 'YES' WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(updateQuery, connection)
                    command.Parameters.AddWithValue("@regnumber", regNumber)
                    command.ExecuteNonQuery()
                End Using
            End Using
            LoadRentData()
            LoadAvailableCars() ' Refresh the available cars list
        End If
        ClearFields()
    End Sub

    Private Sub clearbtn3_Click(sender As Object, e As EventArgs)
        ClearFields()
    End Sub

    Private Sub ClearFields()
        regcbb.SelectedIndex = -1
        regcbb.Text = ""
        customercbb.SelectedIndex = -1
        addressbox.Clear()
        feesbox.Clear()
        DateTimePicker1.Value = Date.Now
        DateTimePicker2.Value = Date.Now
        addbtn3.Enabled = True

        feesbox.Text = "0"

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

        Form2.Show()
        Close()
    End Sub


    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        ReturnCars.Show()
        Close()
    End Sub

    Private Sub rentlistview_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rentlistview.SelectedIndexChanged
        If rentlistview.SelectedItems.Count > 0 Then
            ' Get the selected item
            Dim selectedItem = rentlistview.SelectedItems(0)

            ' Populate regcbb with the regnumber from the selected item
            Dim regNumber = selectedItem.SubItems(1).Text
            regcbb.Text = regNumber

            ' Populate other fields from the selected item
            Dim customerId = selectedItem.SubItems(2).Text
            Dim customerName = selectedItem.SubItems(3).Text
            Dim rentDate = DateTime.Parse(selectedItem.SubItems(4).Text)
            Dim returnDate = DateTime.Parse(selectedItem.SubItems(5).Text)
            Dim address = selectedItem.SubItems(6).Text
            Dim fees = selectedItem.SubItems(7).Text

            ' Set the ComboBox and TextBox values
            customercbb.Text = customerId
            addressbox.Text = address
            DateTimePicker1.Value = rentDate
            DateTimePicker2.Value = returnDate
            feesbox.Text = fees

        Else
            ' Clear fields if no item is selected
            ClearFields()
        End If
    End Sub



    Private Sub customerslbl_Click_1(sender As Object, e As EventArgs) Handles customerslbl.Click
        Customer.Show()
        Close()
    End Sub
End Class
