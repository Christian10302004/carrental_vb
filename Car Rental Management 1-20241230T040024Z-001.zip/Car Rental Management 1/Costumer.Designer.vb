﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Costumer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        costumerslist = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        Panel2 = New Panel()
        PictureBox5 = New PictureBox()
        PictureBox4 = New PictureBox()
        Panel5 = New Panel()
        Label12 = New Label()
        Label11 = New Label()
        PictureBox2 = New PictureBox()
        Label6 = New Label()
        PictureBox3 = New PictureBox()
        Label2 = New Label()
        Label10 = New Label()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label7 = New Label()
        Label5 = New Label()
        Label3 = New Label()
        Panel1 = New Panel()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        TextBox4 = New TextBox()
        Label4 = New Label()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Panel2.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' costumerslist
        ' 
        costumerslist.AllowColumnReorder = True
        costumerslist.AllowDrop = True
        costumerslist.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5})
        costumerslist.GridLines = True
        costumerslist.Location = New Point(17, 335)
        costumerslist.Name = "costumerslist"
        costumerslist.Size = New Size(855, 250)
        costumerslist.TabIndex = 34
        costumerslist.UseCompatibleStateImageBehavior = False
        costumerslist.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "Costumer ID"
        ColumnHeader1.Width = 150
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "FIRST NAME"
        ColumnHeader2.TextAlign = HorizontalAlignment.Center
        ColumnHeader2.Width = 170
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "LAST NAME"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 170
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "CONTACT NO."
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 170
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "ADDRESS"
        ColumnHeader5.TextAlign = HorizontalAlignment.Center
        ColumnHeader5.Width = 200
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(PictureBox5)
        Panel2.Controls.Add(PictureBox4)
        Panel2.Controls.Add(Panel5)
        Panel2.Controls.Add(Label12)
        Panel2.Controls.Add(Label11)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(PictureBox3)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(1, 50)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(883, 47)
        Panel2.TabIndex = 33
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = My.Resources.Resources.returnlog
        PictureBox5.Location = New Point(679, 6)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 33)
        PictureBox5.TabIndex = 22
        PictureBox5.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = My.Resources.Resources.costumerlogo
        PictureBox4.Location = New Point(256, 6)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(33, 33)
        PictureBox4.TabIndex = 24
        PictureBox4.TabStop = False
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.DeepSkyBlue
        Panel5.Location = New Point(253, 39)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(136, 5)
        Panel5.TabIndex = 23
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(711, 15)
        Label12.Name = "Label12"
        Label12.Size = New Size(114, 21)
        Label12.TabIndex = 23
        Label12.Text = "RETURN CARS"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(286, 15)
        Label11.Name = "Label11"
        Label11.Size = New Size(103, 21)
        Label11.TabIndex = 22
        Label11.Text = "COSTUMERS"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.carrentlogo
        PictureBox2.Location = New Point(494, 6)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(33, 33)
        PictureBox2.TabIndex = 20
        PictureBox2.TabStop = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(526, 15)
        Label6.Name = "Label6"
        Label6.Size = New Size(49, 21)
        Label6.TabIndex = 20
        Label6.Text = "RENT"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = My.Resources.Resources.carlogo_1_
        PictureBox3.Location = New Point(79, 7)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(32, 32)
        PictureBox3.TabIndex = 19
        PictureBox3.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(109, 15)
        Label2.Name = "Label2"
        Label2.Size = New Size(50, 21)
        Label2.TabIndex = 18
        Label2.Text = "CARS"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Semibold", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(368, 304)
        Label10.Name = "Label10"
        Label10.Size = New Size(159, 28)
        Label10.TabIndex = 32
        Label10.Text = "COSTUMER LIST"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(680, 164)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(109, 23)
        TextBox3.TabIndex = 28
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(254, 164)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(109, 23)
        TextBox2.TabIndex = 27
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(59, 164)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(109, 23)
        TextBox1.TabIndex = 26
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(659, 140)
        Label7.Name = "Label7"
        Label7.Size = New Size(152, 21)
        Label7.TabIndex = 24
        Label7.Text = "CONTACT NUMBER"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(260, 140)
        Label5.Name = "Label5"
        Label5.Size = New Size(97, 21)
        Label5.TabIndex = 22
        Label5.Text = "LAST NAME"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(63, 140)
        Label3.Name = "Label3"
        Label3.Size = New Size(101, 21)
        Label3.TabIndex = 20
        Label3.Text = "FIRST NAME"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(1, 6)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(883, 44)
        Panel1.TabIndex = 19
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(3, 6)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 33)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.White
        Label1.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(38, 11)
        Label1.Name = "Label1"
        Label1.Size = New Size(137, 21)
        Label1.TabIndex = 1
        Label1.Text = "EGO CAR RENTAL"
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(464, 164)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(109, 23)
        TextBox4.TabIndex = 36
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(477, 140)
        Label4.Name = "Label4"
        Label4.Size = New Size(79, 21)
        Label4.TabIndex = 35
        Label4.Text = "ADDRESS"
        ' 
        ' Button4
        ' 
        Button4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(581, 228)
        Button4.Name = "Button4"
        Button4.Size = New Size(75, 31)
        Button4.TabIndex = 40
        Button4.Text = "CLEAR"
        Button4.TextAlign = ContentAlignment.TopCenter
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(464, 228)
        Button3.Name = "Button3"
        Button3.Size = New Size(75, 31)
        Button3.TabIndex = 39
        Button3.Text = "DELETE"
        Button3.TextAlign = ContentAlignment.TopCenter
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(343, 228)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 31)
        Button2.TabIndex = 38
        Button2.Text = "EDIT"
        Button2.TextAlign = ContentAlignment.TopCenter
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(226, 228)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 31)
        Button1.TabIndex = 37
        Button1.Text = "ADD"
        Button1.TextAlign = ContentAlignment.TopCenter
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Costumer
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(884, 591)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TextBox4)
        Controls.Add(Label4)
        Controls.Add(costumerslist)
        Controls.Add(Panel2)
        Controls.Add(Label10)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label3)
        Controls.Add(Panel1)
        Name = "Costumer"
        Text = "Costumer"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents costumerslist As ListView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
End Class
