﻿Imports MySql.Data.MySqlClient

Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Establish the database connection
        db_connector()

        ' Configure the ListView
        carlist.View = View.Details
        carlist.FullRowSelect = True


        ' Add default items to the ComboBoxes
        brandcbb.Items.AddRange(New String() {"TOYOTA", "NISSAN", "MITSUBISHI", "HONDA", "FORD"})
        availcbb.Items.AddRange(New String() {"YES", "NO"})
        AdjustListViewColumns()
        ' Load the car data from the database
        LoadCarData()
    End Sub
    Private Sub Form2_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        ' Re-adjust columns whenever the form is resized
        AdjustListViewColumns()
    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If carlist.Columns.Count > 0 Then
            Dim totalWidth As Integer = carlist.ClientSize.Width
            Dim columnCount As Integer = carlist.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In carlist.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub

    Private Sub LoadCarData()
        ' Clear the existing items
        carlist.Items.Clear()

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to select all car records
                Dim query As String = "SELECT carid, regnumber, brand, model, color, price, available FROM cars_info"

                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            ' Add each record to the ListView
                            Dim item As New ListViewItem(reader("carid").ToString())
                            item.SubItems.Add(reader("regnumber").ToString())
                            item.SubItems.Add(reader("brand").ToString())
                            item.SubItems.Add(reader("model").ToString())
                            item.SubItems.Add(reader("color").ToString())
                            item.SubItems.Add(reader("price").ToString())
                            item.SubItems.Add(reader("available").ToString())

                            carlist.Items.Add(item)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while loading car data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub carlist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles carlist.SelectedIndexChanged
        If carlist.SelectedItems.Count > 0 Then
            ' Get the selected item
            Dim selectedItem As ListViewItem = carlist.SelectedItems(0)

            ' Populate the textboxes and ComboBoxes with the selected car details
            regbox.Text = selectedItem.SubItems(1).Text
            brandcbb.Text = selectedItem.SubItems(2).Text
            modelbox.Text = selectedItem.SubItems(3).Text
            colorbox.Text = selectedItem.SubItems(4).Text
            pricebox.Text = selectedItem.SubItems(5).Text
            availcbb.Text = selectedItem.SubItems(6).Text
            ' Disable editing of the Reg Number
            regbox.Enabled = False
            addbtn1.Enabled = False
        End If
    End Sub


    Private Sub addbtn1_Click(sender As Object, e As EventArgs) Handles addbtn1.Click
        ' Get the input values

        Dim regnumber = regbox.Text
        Dim brand = brandcbb.Text
        Dim model = modelbox.Text
        Dim color = colorbox.Text
        Dim price As Decimal
        Dim available = availcbb.Text
        ' Validate the input
        If Not ValidateInputs(regnumber, brand, model, color, price, available) Then Return

        If Not ValidateModelAndColor(model, color) Then Return
        ' Check for duplicate regnumber
        If IsRegNumberDuplicate(regnumber) Then
            MessageBox.Show("This registration number already exists.", "Duplicate Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Connection string
        Dim connectionString = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to insert a new car record
                Dim query = "INSERT INTO cars_info (regnumber, brand, model, color, price, available) VALUES (@regnumber, @brand, @model, @color, @price, @available)"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.Parameters.AddWithValue("@brand", brand)
                    command.Parameters.AddWithValue("@model", model)
                    command.Parameters.AddWithValue("@color", color)
                    command.Parameters.AddWithValue("@price", price)
                    command.Parameters.AddWithValue("@available", available)

                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView
            LoadCarData()

            ' Clear the input fields
            ClearFields()

            MessageBox.Show("Car added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while adding the car: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function ValidateInputs(regnumber As String, brand As String, model As String, color As String, ByRef price As Decimal, available As String) As Boolean
        ' Validate the brand, model, color, and availability
        If String.IsNullOrWhiteSpace(brand) OrElse String.IsNullOrWhiteSpace(model) OrElse
           String.IsNullOrWhiteSpace(color) OrElse String.IsNullOrWhiteSpace(available) Then
            MessageBox.Show("Please enter valid car details or fill all forms.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validate the registration number format
        Dim regNumberPattern As String = "^[A-Z]{3} \d{4}$"
        If Not System.Text.RegularExpressions.Regex.IsMatch(regnumber, regNumberPattern) Then
            MessageBox.Show("Registration number must be in the format LLL NNNN (e.g., ABC 1234).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validate the price
        If Not Decimal.TryParse(pricebox.Text, price) Then
            MessageBox.Show("Price must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Function IsRegNumberDuplicate(regnumber As String) As Boolean
        ' Check if the registration number already exists in the database
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password
        Dim exists As Boolean = False

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                Dim query As String = "SELECT COUNT(*) FROM cars_info WHERE regnumber = @regnumber"
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    exists = Convert.ToInt32(command.ExecuteScalar()) > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while checking for duplicate registration number: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return exists
    End Function

    Private Sub editbtn1_Click(sender As Object, e As EventArgs) Handles editbtn1.Click
        If carlist.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a car to edit.", "Edit Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get the selected car ID (from the ListView)
        Dim selectedItem As ListViewItem = carlist.SelectedItems(0)
        Dim carID As Integer = Convert.ToInt32(selectedItem.SubItems(0).Text)
        Dim regNumber1 As String = selectedItem.SubItems(1).Text


        If IsCarRented(regNumber1) Then
            MessageBox.Show("This car is currently rented and cannot be marked as available.", "Car Rented", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit if car is rented
        End If

        ' Get the input values
        Dim regnumber As String = regbox.Text
        Dim brand As String = brandcbb.Text
        Dim model As String = modelbox.Text
        Dim color As String = colorbox.Text
        Dim price As Decimal
        Dim available As String = availcbb.Text

        ' Validate the input values
        If Not ValidateInputs(regnumber, brand, model, color, price, available) Then Return
        If Not ValidateModelAndColor(model, color) Then Return


        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to update the car record
                Dim query As String = "UPDATE cars_info SET regnumber = @regnumber, brand = @brand, model = @model, color = @color, price = @price, available = @available WHERE carid = @carid"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@carid", carID)
                    command.Parameters.AddWithValue("@regnumber", regnumber)
                    command.Parameters.AddWithValue("@brand", brand)
                    command.Parameters.AddWithValue("@model", model)
                    command.Parameters.AddWithValue("@color", color)
                    command.Parameters.AddWithValue("@price", price)
                    command.Parameters.AddWithValue("@available", available)

                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView
            LoadCarData()

            ' Clear the input fields
            ClearFields()

            MessageBox.Show("Car updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while updating the car: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function IsCarRented(regNumber As String) As Boolean
        Dim query As String = "SELECT COUNT(*) FROM rent_info WHERE regnumber = @regnumber"
        Dim rentedCount As Integer

        Dim connectionString As String = "server=localhost;user=root;database=carrental;password="

        Try
            Using connection As New MySqlConnection(connectionString)
                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@regnumber", regNumber)
                    connection.Open()
                    rentedCount = Convert.ToInt32(command.ExecuteScalar())
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while checking the rental status: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

        Return rentedCount > 0
    End Function



    Private Sub ClearFields()
        regbox.Clear()
        brandcbb.SelectedIndex = -1
        modelbox.Clear()
        colorbox.Clear()
        pricebox.Clear()
        availcbb.SelectedIndex = -1
        regbox.Enabled = True ' Re-enable regbox for new entries
        addbtn1.Enabled = True
    End Sub

    Private Sub deletebtn1_Click(sender As Object, e As EventArgs) Handles deletebtn1.Click
        If carlist.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a car to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim selectedItem As ListViewItem = carlist.SelectedItems(0)
        Dim carID As Integer = Convert.ToInt32(selectedItem.SubItems(0).Text)

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to delete the car record
                Dim query As String = "DELETE FROM cars_info WHERE carid = @carid"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@carid", carID)
                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView
            LoadCarData()
            ClearFields()
            MessageBox.Show("Car deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while deleting the car: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function ValidateModelAndColor(model As String, color As String) As Boolean
        ' Validate model: must contain at least one letter
        If Not model.Any(Function(c) Char.IsLetter(c)) Then
            MessageBox.Show("Model must contain at least one letter or be a combination of letters and numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validate color: must contain only letters
        If Not color.All(Function(c) Char.IsLetter(c)) Then
            MessageBox.Show("Color must contain only letters.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function


    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Dim rent As New Rent()
        rent.Show()
        Close()
    End Sub

    Private Sub clearbtn1_Click(sender As Object, e As EventArgs) Handles clearbtn1.Click
        ClearFields()

    End Sub

    Private Sub customerslbl_Click(sender As Object, e As EventArgs) Handles customerslbl.Click
        Dim customer As New Customer()
        customer.Show()
        Close()
    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        ReturnCars.Show()
        Close()
    End Sub
End Class
