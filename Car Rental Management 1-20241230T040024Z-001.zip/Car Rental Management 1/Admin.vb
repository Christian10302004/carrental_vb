﻿Imports MySql.Data.MySqlClient

Public Class Admin
    Private Sub Admin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        db_connector()
        gendercbb.Items.AddRange(New String() {"MALE", "FEMALE", "OTHER", "RATHER NOT SAY", "GE LANG"})
        LoadEmployees() ' Ensure the employee data is loaded when the form is first opened
        AdjustListViewColumns()
        employeeslistview.View = View.Details ' Ensure view is set to Details
        employeeslistview.FullRowSelect = True
    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If employeeslistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = employeeslistview.ClientSize.Width
            Dim columnCount As Integer = employeeslistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In employeeslistview.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub
    ' Load data into ListView
    Private Sub LoadEmployees()
        Try
            Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                conn.Open()
                Dim query As String = "SELECT * FROM employees_info"
                Dim command As New MySqlCommand(query, conn)
                Dim reader As MySqlDataReader = command.ExecuteReader()

                employeeslistview.Items.Clear()

                While reader.Read()
                    Dim item As New ListViewItem(reader("employeesid").ToString())
                    item.SubItems.Add(reader("firstname").ToString())
                    item.SubItems.Add(reader("middlename").ToString())
                    item.SubItems.Add(reader("lastname").ToString())
                    item.SubItems.Add(reader("age").ToString())
                    item.SubItems.Add(reader("address").ToString())
                    item.SubItems.Add(reader("gender").ToString())
                    employeeslistview.Items.Add(item)
                End While
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Add employee
    Private Sub addbtn_Click(sender As Object, e As EventArgs) Handles addbtn.Click
        If ValidateInputs() Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()
                    Dim query As String = "INSERT INTO employees_info (firstname, middlename, lastname, age, address, gender) 
                                           VALUES (@firstname, @middlename, @lastname, @age, @address, @gender)"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@firstname", firstname.Text)
                    command.Parameters.AddWithValue("@middlename", middlename.Text)
                    command.Parameters.AddWithValue("@lastname", lastname.Text)
                    command.Parameters.AddWithValue("@age", age.Text)
                    command.Parameters.AddWithValue("@address", address.Text)
                    command.Parameters.AddWithValue("@gender", gendercbb.Text)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Employee added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    LoadEmployees() ' Refresh the ListView
                End Using
                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error adding employee: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    ' Edit employee
    Private Sub editbtn_Click(sender As Object, e As EventArgs) Handles editbtn.Click
        If ValidateInputs() AndAlso employeeslistview.SelectedItems.Count > 0 Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()
                    Dim selectedID As String = employeeslistview.SelectedItems(0).Text
                    Dim query As String = "UPDATE employees_info 
                                           SET firstname = @firstname, middlename = @middlename, lastname = @lastname, 
                                               age = @age, address = @address, gender = @gender
                                           WHERE employeesid = @id"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@firstname", firstname.Text)
                    command.Parameters.AddWithValue("@middlename", middlename.Text)
                    command.Parameters.AddWithValue("@lastname", lastname.Text)
                    command.Parameters.AddWithValue("@age", age.Text)
                    command.Parameters.AddWithValue("@address", address.Text)
                    command.Parameters.AddWithValue("@gender", gendercbb.Text)
                    command.Parameters.AddWithValue("@id", selectedID)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Employee updated successfully!")
                    LoadEmployees() ' Refresh the ListView
                End Using
                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error editing employee: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    ' Delete employee
    Private Sub deletebtn_Click(sender As Object, e As EventArgs) Handles deletebtn.Click
        If employeeslistview.SelectedItems.Count > 0 Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()
                    Dim selectedID As String = employeeslistview.SelectedItems(0).Text
                    Dim query As String = "DELETE FROM employees_info WHERE employeesid = @id"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@id", selectedID)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Employee deleted successfully!")
                    LoadEmployees() ' Refresh the ListView
                End Using
                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error deleting employee: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Please select an employee to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If


    End Sub

    ' Clear inputs
    Private Sub clearbtn_Click(sender As Object, e As EventArgs) Handles clearbtn.Click
        ClearInputs()
    End Sub

    ' Validate inputs
    ' Validate inputs
    Private Function ValidateInputs() As Boolean
        ' Check if any field is empty
        If String.IsNullOrWhiteSpace(firstname.Text) OrElse
       String.IsNullOrWhiteSpace(lastname.Text) OrElse
       String.IsNullOrWhiteSpace(age.Text) OrElse
       String.IsNullOrWhiteSpace(address.Text) OrElse
       gendercbb.SelectedIndex = -1 Then
            MessageBox.Show("Please fill out all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Check if the age is a valid number and between 18 and 100
        Dim enteredAge As Integer
        If Not Integer.TryParse(age.Text, enteredAge) OrElse enteredAge < 18 OrElse enteredAge > 100 Then
            MessageBox.Show("Age must be a valid number between 18 and 100.", "Invalid Age", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Check if names and address are valid
        If Not ValidateNameAndAddress() Then
            Return False
        End If

        ' If all checks pass
        Return True
    End Function

    ' Function to validate name and address
    Private Function ValidateNameAndAddress() As Boolean
        ' Validate First Name, Middle Name, Last Name (only letters allowed)
        Dim nameRegex As New Text.RegularExpressions.Regex("^[A-Za-z]+$")
        If Not nameRegex.IsMatch(firstname.Text) Then
            MessageBox.Show("First name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            firstname.Focus()
            Return False
        End If
        If Not nameRegex.IsMatch(middlename.Text) Then
            MessageBox.Show("Middle name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            middlename.Focus()
            Return False
        End If
        If Not nameRegex.IsMatch(lastname.Text) Then
            MessageBox.Show("Last name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            lastname.Focus()
            Return False
        End If

        ' Validate Address (letters, or letters combined with numbers, but not numbers only)
        Dim addressRegex As New Text.RegularExpressions.Regex("^(?=.*[A-Za-z])[A-Za-z0-9\s]+$")
        If Not addressRegex.IsMatch(address.Text) Then
            MessageBox.Show("Address must contain letters or a combination of letters and numbers (not numbers only).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            address.Focus()
            Return False
        End If

        Return True
    End Function

    Private Sub employeeslistview_SelectedIndexChanged(sender As Object, e As EventArgs) Handles employeeslistview.SelectedIndexChanged
        If employeeslistview.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = employeeslistview.SelectedItems(0)

            ' Populate textboxes with ListView data
            firstname.Text = selectedItem.SubItems(1).Text
            middlename.Text = selectedItem.SubItems(2).Text
            lastname.Text = selectedItem.SubItems(3).Text
            age.Text = selectedItem.SubItems(4).Text
            address.Text = selectedItem.SubItems(5).Text

            ' Select gender in ComboBox
            Dim gender As String = selectedItem.SubItems(6).Text
            If gendercbb.Items.Contains(gender) Then
                gendercbb.SelectedItem = gender
            Else
                gendercbb.SelectedIndex = -1 ' If not found, reset the selection
            End If

            addbtn.Enabled = False ' Disable Add button when an item is selected
        Else

        End If
    End Sub


    ' Clear input fields
    Private Sub ClearInputs()
        firstname.Clear()
        middlename.Clear()
        lastname.Clear()
        age.Clear()
        address.Clear()
        gendercbb.SelectedIndex = -1
        addbtn.Enabled = True
    End Sub

    Private Sub customerslbl_Click(sender As Object, e As EventArgs) Handles customerslbl.Click
        Accounts.Show()
        Me.Close()
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click
        AdminLogin.Show()
        Me.Close()
    End Sub


End Class
