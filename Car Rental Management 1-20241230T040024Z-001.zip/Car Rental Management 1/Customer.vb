﻿Imports MySql.Data.MySqlClient

Public Class Customer
    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Configure the ListView
        customerListView.View = View.Details
        customerListView.FullRowSelect = True

        AdjustListViewColumns()
        ' Load the customer data from the database
        LoadCustomerData()
    End Sub
    Private Sub Customer_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        ' Re-adjust columns whenever the form is resized
        AdjustListViewColumns()
    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If customerListView.Columns.Count > 0 Then
            Dim totalWidth As Integer = customerListView.ClientSize.Width
            Dim columnCount As Integer = customerListView.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In customerListView.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub
    Private Sub LoadCustomerData()
        ' Clear the existing items
        customerListView.Items.Clear()

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to select all customer records
                Dim query As String = "SELECT customerid, firstname, lastname, address, contactno FROM customer_info"

                Using command As New MySqlCommand(query, connection)
                    Using reader As MySqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            ' Add each record to the ListView
                            Dim item As New ListViewItem(reader("customerid").ToString())
                            item.SubItems.Add(reader("firstname").ToString())
                            item.SubItems.Add(reader("lastname").ToString())
                            item.SubItems.Add(reader("address").ToString())
                            item.SubItems.Add(reader("contactno").ToString())

                            customerListView.Items.Add(item)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while loading customer data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub customerListView_SelectedIndexChanged(sender As Object, e As EventArgs) Handles customerListView.SelectedIndexChanged
        If customerListView.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = customerListView.SelectedItems(0)
            fnamebox.Text = selectedItem.SubItems(1).Text
            lnamebox.Text = selectedItem.SubItems(2).Text
            addressbox.Text = selectedItem.SubItems(3).Text
            contactbox.Text = selectedItem.SubItems(4).Text
            addbtn2.Enabled = False
        End If
    End Sub

    Private Sub addbtn2_Click(sender As Object, e As EventArgs) Handles addbtn2.Click
        ' Check if any of the required fields are empty
        If String.IsNullOrWhiteSpace(fnamebox.Text) OrElse
       String.IsNullOrWhiteSpace(lnamebox.Text) OrElse
       String.IsNullOrWhiteSpace(addressbox.Text) Then

            MessageBox.Show("Please fill out all the text boxes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If Not ValidateCustomerInput() Then
            Return
        End If

        ' Get the input values
        Dim firstname As String = fnamebox.Text
        Dim lastname As String = lnamebox.Text
        Dim address As String = addressbox.Text
        Dim contactno As String = contactbox.Text

        ' Validate contact number length
        If contactno.Length <> 11 OrElse Not IsNumeric(contactno) Then
            MessageBox.Show("Contact number must be exactly 11 numeric characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Check for duplicate contact number
        If IsContactNumberDuplicate(contactno) Then
            MessageBox.Show("A customer with this contact number already exists.", "Duplicate Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Insert query to add a new customer
                Dim query As String = "INSERT INTO customer_info (firstname, lastname, address, contactno) VALUES (@firstname, @lastname, @address, @contactno)"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@firstname", firstname)
                    command.Parameters.AddWithValue("@lastname", lastname)
                    command.Parameters.AddWithValue("@address", address)
                    command.Parameters.AddWithValue("@contactno", contactno)

                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView to show the new data
            LoadCustomerData()

            ' Clear the input fields after adding
            ClearFields()

            MessageBox.Show("Customer added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while adding the customer: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function IsContactNumberDuplicate(contactno As String) As Boolean
        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to check if contact number already exists
                Dim query As String = "SELECT COUNT(*) FROM customer_info WHERE contactno = @contactno"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@contactno", contactno)
                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

                    ' If count is greater than 0, it means duplicate exists
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while checking the contact number: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return True ' Assume duplicate to prevent adding in case of an error
        End Try
    End Function

    Private Sub editbtn2_Click(sender As Object, e As EventArgs) Handles editbtn2.Click
        If customerListView.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a customer to edit.", "Edit Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        If Not ValidateCustomerInput() Then
            Return
        End If

        ' Get the selected customer ID (from the ListView)
        Dim selectedItem As ListViewItem = customerListView.SelectedItems(0)
        Dim customerID As Integer = Convert.ToInt32(selectedItem.SubItems(0).Text)

        ' Get the input values
        Dim firstname As String = fnamebox.Text
        Dim lastname As String = lnamebox.Text
        Dim address As String = addressbox.Text
        Dim contactno As String = contactbox.Text

        ' Validate contact number length
        If contactno.Length <> 11 OrElse Not IsNumeric(contactno) Then
            MessageBox.Show("Contact number must be exactly 11 numeric characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to update the customer record
                Dim query As String = "UPDATE customer_info SET firstname = @firstname, lastname = @lastname, address = @address, contactno = @contactno WHERE customerid = @customerid"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@firstname", firstname)
                    command.Parameters.AddWithValue("@lastname", lastname)
                    command.Parameters.AddWithValue("@address", address)
                    command.Parameters.AddWithValue("@contactno", contactno)
                    command.Parameters.AddWithValue("@customerid", customerID)

                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView
            LoadCustomerData()

            ' Clear the input fields
            ClearFields()

            MessageBox.Show("Customer updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while updating the customer: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function ValidateCustomerInput() As Boolean
        Dim namePattern As String = "^[a-zA-Z]+$"
        Dim addressPattern As String = "^(?=.*[a-zA-Z])([a-zA-Z0-9\s]+)$" ' Must contain at least one letter

        ' Validate firstname
        If Not System.Text.RegularExpressions.Regex.IsMatch(fnamebox.Text.Trim(), namePattern) Then
            MessageBox.Show("First Name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Validate lastname
        If Not System.Text.RegularExpressions.Regex.IsMatch(lnamebox.Text.Trim(), namePattern) Then
            MessageBox.Show("Last Name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Validate address
        If Not System.Text.RegularExpressions.Regex.IsMatch(addressbox.Text.Trim(), addressPattern) Then
            MessageBox.Show("Address must contain letters or a combination of letters and numbers, not numbers only.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function

    Private Sub deletebtn2_Click(sender As Object, e As EventArgs) Handles deletebtn2.Click
        If customerListView.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select a customer to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get the selected customer ID
        Dim selectedItem As ListViewItem = customerListView.SelectedItems(0)
        Dim customerID As Integer = Convert.ToInt32(selectedItem.SubItems(0).Text)

        ' Connection string
        Dim connectionString As String = "server=localhost;user=root;database=carrental;password=" ' Update with your actual password

        Try
            Using connection As New MySqlConnection(connectionString)
                connection.Open()

                ' Query to delete the customer record
                Dim query As String = "DELETE FROM customer_info WHERE customerid = @customerid"

                Using command As New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@customerid", customerID)
                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the ListView
            LoadCustomerData()

            ' Clear the input fields
            ClearFields()

            MessageBox.Show("Customer deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("An error occurred while deleting the customer: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub clearbtn2_Click(sender As Object, e As EventArgs) Handles clearbtn2.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        fnamebox.Clear()
        lnamebox.Clear()
        addressbox.Clear()
        contactbox.Clear()
        addbtn2.Enabled = True
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Form2.Show()
        Close()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Rent.Show()
        Close()
    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        ReturnCars.Show()
        Close()
    End Sub
End Class
