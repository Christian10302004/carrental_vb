﻿Imports MySql.Data.MySqlClient

Module Module1
    Public conn As MySqlConnection
    Public Sub db_connector()
        conn = New MySqlConnection
        conn.ConnectionString = "server = localhost; user = root;  database = carrental; password = "
        Try
            conn.Open()
        Catch ex As Exception
            MsgBox("Connectio Error! (Not Connected to the Database)", MsgBoxStyle.Critical, "Error")
        End Try
    End Sub
End Module

