﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Customer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel8 = New TableLayoutPanel()
        Label6 = New Label()
        PictureBox6 = New PictureBox()
        TableLayoutPanel7 = New TableLayoutPanel()
        customerslbl = New Label()
        PictureBox5 = New PictureBox()
        TableLayoutPanel5 = New TableLayoutPanel()
        Label12 = New Label()
        PictureBox2 = New PictureBox()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        TableLayoutPanel9 = New TableLayoutPanel()
        TableLayoutPanel12 = New TableLayoutPanel()
        Label7 = New Label()
        contactbox = New TextBox()
        TableLayoutPanel10 = New TableLayoutPanel()
        Label5 = New Label()
        addressbox = New TextBox()
        TableLayoutPanel6 = New TableLayoutPanel()
        Label1 = New Label()
        lnamebox = New TextBox()
        TableLayoutPanel11 = New TableLayoutPanel()
        Label4 = New Label()
        fnamebox = New TextBox()
        TableLayoutPanel17 = New TableLayoutPanel()
        addbtn2 = New Button()
        clearbtn2 = New Button()
        deletebtn2 = New Button()
        editbtn2 = New Button()
        TableLayoutPanel18 = New TableLayoutPanel()
        Label14 = New Label()
        customerListView = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel8.SuspendLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel7.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel5.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel9.SuspendLayout()
        TableLayoutPanel12.SuspendLayout()
        TableLayoutPanel10.SuspendLayout()
        TableLayoutPanel6.SuspendLayout()
        TableLayoutPanel11.SuspendLayout()
        TableLayoutPanel17.SuspendLayout()
        TableLayoutPanel18.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel9, 0, 2)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel17, 0, 3)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel18, 0, 4)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 5
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 8F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 9F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 26F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 7F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel1.Size = New Size(934, 611)
        TableLayoutPanel1.TabIndex = 2
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.BackColor = Color.White
        TableLayoutPanel2.ColumnCount = 2
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 5F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 95F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 0)
        TableLayoutPanel2.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 3)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(928, 42)
        TableLayoutPanel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(49, 10)
        Label2.Name = "Label2"
        Label2.Size = New Size(137, 21)
        Label2.TabIndex = 21
        Label2.Text = "EGO CAR RENTAL"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(10, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 33)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.BackColor = Color.White
        TableLayoutPanel3.ColumnCount = 4
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel8, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel7, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel5, 1, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 51)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(928, 48)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' TableLayoutPanel8
        ' 
        TableLayoutPanel8.ColumnCount = 2
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.Controls.Add(Label6, 0, 0)
        TableLayoutPanel8.Controls.Add(PictureBox6, 0, 0)
        TableLayoutPanel8.Dock = DockStyle.Fill
        TableLayoutPanel8.Location = New Point(466, 3)
        TableLayoutPanel8.Name = "TableLayoutPanel8"
        TableLayoutPanel8.RowCount = 1
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel8.Size = New Size(179, 42)
        TableLayoutPanel8.TabIndex = 3
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(92, 8)
        Label6.Name = "Label6"
        Label6.Size = New Size(59, 25)
        Label6.TabIndex = 23
        Label6.Text = "RENT"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Anchor = AnchorStyles.Right
        PictureBox6.Image = My.Resources.Resources.car__1_
        PictureBox6.Location = New Point(53, 4)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(33, 33)
        PictureBox6.TabIndex = 22
        PictureBox6.TabStop = False
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 2
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel7.Controls.Add(customerslbl, 0, 0)
        TableLayoutPanel7.Controls.Add(PictureBox5, 0, 0)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(281, 3)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 1
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel7.Size = New Size(179, 42)
        TableLayoutPanel7.TabIndex = 2
        ' 
        ' customerslbl
        ' 
        customerslbl.Anchor = AnchorStyles.Left
        customerslbl.AutoSize = True
        customerslbl.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        customerslbl.Location = New Point(56, 8)
        customerslbl.Name = "customerslbl"
        customerslbl.Size = New Size(120, 25)
        customerslbl.TabIndex = 26
        customerslbl.Text = "CUSTOMERS"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Right
        PictureBox5.Image = My.Resources.Resources.rating
        PictureBox5.Location = New Point(17, 4)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 33)
        PictureBox5.TabIndex = 25
        PictureBox5.TabStop = False
        ' 
        ' TableLayoutPanel5
        ' 
        TableLayoutPanel5.ColumnCount = 2
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel5.Controls.Add(Label12, 0, 0)
        TableLayoutPanel5.Controls.Add(PictureBox2, 0, 0)
        TableLayoutPanel5.Dock = DockStyle.Fill
        TableLayoutPanel5.Location = New Point(651, 3)
        TableLayoutPanel5.Name = "TableLayoutPanel5"
        TableLayoutPanel5.RowCount = 1
        TableLayoutPanel5.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel5.Size = New Size(274, 42)
        TableLayoutPanel5.TabIndex = 1
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Left
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(85, 8)
        Label12.Name = "Label12"
        Label12.Size = New Size(136, 25)
        Label12.TabIndex = 24
        Label12.Text = "RETURN CARS"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Right
        PictureBox2.Image = My.Resources.Resources._return
        PictureBox2.Location = New Point(46, 4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(33, 33)
        PictureBox2.TabIndex = 23
        PictureBox2.TabStop = False
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel4.Controls.Add(Label3, 1, 0)
        TableLayoutPanel4.Dock = DockStyle.Fill
        TableLayoutPanel4.Location = New Point(3, 3)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Size = New Size(272, 42)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.car
        PictureBox3.Location = New Point(100, 4)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(33, 33)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Left
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(139, 8)
        Label3.Name = "Label3"
        Label3.Size = New Size(59, 25)
        Label3.TabIndex = 21
        Label3.Text = "CARS"
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel9.ColumnCount = 4
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25F))
        TableLayoutPanel9.Controls.Add(TableLayoutPanel12, 3, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel10, 2, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel6, 1, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel11, 0, 0)
        TableLayoutPanel9.Dock = DockStyle.Fill
        TableLayoutPanel9.Location = New Point(3, 105)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 1
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel9.Size = New Size(928, 152)
        TableLayoutPanel9.TabIndex = 2
        ' 
        ' TableLayoutPanel12
        ' 
        TableLayoutPanel12.BackColor = Color.White
        TableLayoutPanel12.ColumnCount = 1
        TableLayoutPanel12.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Controls.Add(Label7, 0, 0)
        TableLayoutPanel12.Controls.Add(contactbox, 0, 1)
        TableLayoutPanel12.Dock = DockStyle.Fill
        TableLayoutPanel12.Location = New Point(699, 3)
        TableLayoutPanel12.Name = "TableLayoutPanel12"
        TableLayoutPanel12.RowCount = 2
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Size = New Size(226, 146)
        TableLayoutPanel12.TabIndex = 4
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Bottom
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(45, 48)
        Label7.Name = "Label7"
        Label7.Size = New Size(135, 25)
        Label7.TabIndex = 6
        Label7.Text = "CONTACT NO."
        ' 
        ' contactbox
        ' 
        contactbox.Anchor = AnchorStyles.Top
        contactbox.Font = New Font("Segoe UI", 12F)
        contactbox.Location = New Point(48, 76)
        contactbox.Name = "contactbox"
        contactbox.Size = New Size(130, 29)
        contactbox.TabIndex = 3
        ' 
        ' TableLayoutPanel10
        ' 
        TableLayoutPanel10.BackColor = Color.White
        TableLayoutPanel10.ColumnCount = 1
        TableLayoutPanel10.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Controls.Add(Label5, 0, 0)
        TableLayoutPanel10.Controls.Add(addressbox, 0, 1)
        TableLayoutPanel10.Dock = DockStyle.Fill
        TableLayoutPanel10.Location = New Point(467, 3)
        TableLayoutPanel10.Name = "TableLayoutPanel10"
        TableLayoutPanel10.RowCount = 2
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Size = New Size(226, 146)
        TableLayoutPanel10.TabIndex = 3
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Bottom
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(65, 48)
        Label5.Name = "Label5"
        Label5.Size = New Size(95, 25)
        Label5.TabIndex = 6
        Label5.Text = "ADDRESS"
        ' 
        ' addressbox
        ' 
        addressbox.Anchor = AnchorStyles.Top
        addressbox.Font = New Font("Segoe UI", 12F)
        addressbox.Location = New Point(48, 76)
        addressbox.Name = "addressbox"
        addressbox.Size = New Size(130, 29)
        addressbox.TabIndex = 2
        ' 
        ' TableLayoutPanel6
        ' 
        TableLayoutPanel6.BackColor = Color.White
        TableLayoutPanel6.ColumnCount = 1
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Controls.Add(Label1, 0, 0)
        TableLayoutPanel6.Controls.Add(lnamebox, 0, 1)
        TableLayoutPanel6.Dock = DockStyle.Fill
        TableLayoutPanel6.Location = New Point(235, 3)
        TableLayoutPanel6.Name = "TableLayoutPanel6"
        TableLayoutPanel6.RowCount = 2
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Size = New Size(226, 146)
        TableLayoutPanel6.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Bottom
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(55, 48)
        Label1.Name = "Label1"
        Label1.Size = New Size(115, 25)
        Label1.TabIndex = 6
        Label1.Text = "LAST NAME"
        ' 
        ' lnamebox
        ' 
        lnamebox.Anchor = AnchorStyles.Top
        lnamebox.Font = New Font("Segoe UI", 12F)
        lnamebox.Location = New Point(48, 76)
        lnamebox.Name = "lnamebox"
        lnamebox.Size = New Size(130, 29)
        lnamebox.TabIndex = 1
        ' 
        ' TableLayoutPanel11
        ' 
        TableLayoutPanel11.BackColor = Color.White
        TableLayoutPanel11.ColumnCount = 1
        TableLayoutPanel11.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Controls.Add(Label4, 0, 0)
        TableLayoutPanel11.Controls.Add(fnamebox, 0, 1)
        TableLayoutPanel11.Dock = DockStyle.Fill
        TableLayoutPanel11.Location = New Point(3, 3)
        TableLayoutPanel11.Name = "TableLayoutPanel11"
        TableLayoutPanel11.RowCount = 2
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Size = New Size(226, 146)
        TableLayoutPanel11.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(52, 48)
        Label4.Name = "Label4"
        Label4.Size = New Size(121, 25)
        Label4.TabIndex = 6
        Label4.Text = "FIRST NAME"
        ' 
        ' fnamebox
        ' 
        fnamebox.Anchor = AnchorStyles.Top
        fnamebox.Font = New Font("Segoe UI", 12F)
        fnamebox.Location = New Point(48, 76)
        fnamebox.Name = "fnamebox"
        fnamebox.Size = New Size(130, 29)
        fnamebox.TabIndex = 0
        ' 
        ' TableLayoutPanel17
        ' 
        TableLayoutPanel17.BackColor = Color.White
        TableLayoutPanel17.ColumnCount = 4
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.Controls.Add(addbtn2, 0, 0)
        TableLayoutPanel17.Controls.Add(clearbtn2, 3, 0)
        TableLayoutPanel17.Controls.Add(deletebtn2, 2, 0)
        TableLayoutPanel17.Controls.Add(editbtn2, 1, 0)
        TableLayoutPanel17.Dock = DockStyle.Fill
        TableLayoutPanel17.Location = New Point(3, 263)
        TableLayoutPanel17.Name = "TableLayoutPanel17"
        TableLayoutPanel17.RowCount = 1
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel17.Size = New Size(928, 36)
        TableLayoutPanel17.TabIndex = 3
        ' 
        ' addbtn2
        ' 
        addbtn2.Anchor = AnchorStyles.Right
        addbtn2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        addbtn2.Location = New Point(175, 3)
        addbtn2.Name = "addbtn2"
        addbtn2.Size = New Size(100, 30)
        addbtn2.TabIndex = 7
        addbtn2.Text = "ADD"
        addbtn2.TextAlign = ContentAlignment.TopCenter
        addbtn2.UseVisualStyleBackColor = True
        ' 
        ' clearbtn2
        ' 
        clearbtn2.Anchor = AnchorStyles.Left
        clearbtn2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        clearbtn2.Location = New Point(651, 3)
        clearbtn2.Name = "clearbtn2"
        clearbtn2.Size = New Size(100, 30)
        clearbtn2.TabIndex = 10
        clearbtn2.Text = "CLEAR"
        clearbtn2.TextAlign = ContentAlignment.TopCenter
        clearbtn2.UseVisualStyleBackColor = True
        ' 
        ' deletebtn2
        ' 
        deletebtn2.Anchor = AnchorStyles.None
        deletebtn2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        deletebtn2.Location = New Point(505, 3)
        deletebtn2.Name = "deletebtn2"
        deletebtn2.Size = New Size(100, 30)
        deletebtn2.TabIndex = 9
        deletebtn2.Text = "DELETE"
        deletebtn2.TextAlign = ContentAlignment.TopCenter
        deletebtn2.UseVisualStyleBackColor = True
        ' 
        ' editbtn2
        ' 
        editbtn2.Anchor = AnchorStyles.None
        editbtn2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        editbtn2.Location = New Point(320, 3)
        editbtn2.Name = "editbtn2"
        editbtn2.Size = New Size(100, 30)
        editbtn2.TabIndex = 8
        editbtn2.Text = "EDIT"
        editbtn2.TextAlign = ContentAlignment.TopCenter
        editbtn2.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel18
        ' 
        TableLayoutPanel18.BackColor = Color.White
        TableLayoutPanel18.ColumnCount = 1
        TableLayoutPanel18.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel18.Controls.Add(Label14, 0, 0)
        TableLayoutPanel18.Controls.Add(customerListView, 0, 1)
        TableLayoutPanel18.Dock = DockStyle.Fill
        TableLayoutPanel18.Location = New Point(3, 305)
        TableLayoutPanel18.Name = "TableLayoutPanel18"
        TableLayoutPanel18.RowCount = 2
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 12F))
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 88F))
        TableLayoutPanel18.Size = New Size(928, 303)
        TableLayoutPanel18.TabIndex = 4
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.None
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(380, 5)
        Label14.Name = "Label14"
        Label14.Size = New Size(167, 25)
        Label14.TabIndex = 17
        Label14.Text = "CUSTOMERS LIST"
        ' 
        ' customerListView
        ' 
        customerListView.BorderStyle = BorderStyle.FixedSingle
        customerListView.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5})
        customerListView.Dock = DockStyle.Fill
        customerListView.Font = New Font("Segoe UI", 11F)
        customerListView.GridLines = True
        customerListView.Location = New Point(3, 39)
        customerListView.Name = "customerListView"
        customerListView.Size = New Size(922, 261)
        customerListView.TabIndex = 11
        customerListView.UseCompatibleStateImageBehavior = False
        customerListView.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "CUSTOMER ID"
        ColumnHeader1.Width = 150
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "FIRST NAME"
        ColumnHeader2.TextAlign = HorizontalAlignment.Center
        ColumnHeader2.Width = 200
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "LAST NAME"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 200
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "ADDRESS"
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 200
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "CONTACT NO"
        ColumnHeader5.TextAlign = HorizontalAlignment.Center
        ColumnHeader5.Width = 200
        ' 
        ' Customer
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(934, 611)
        Controls.Add(TableLayoutPanel1)
        Name = "Customer"
        Text = "Customer"
        WindowState = FormWindowState.Maximized
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel8.ResumeLayout(False)
        TableLayoutPanel8.PerformLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel7.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel5.ResumeLayout(False)
        TableLayoutPanel5.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel9.ResumeLayout(False)
        TableLayoutPanel12.ResumeLayout(False)
        TableLayoutPanel12.PerformLayout()
        TableLayoutPanel10.ResumeLayout(False)
        TableLayoutPanel10.PerformLayout()
        TableLayoutPanel6.ResumeLayout(False)
        TableLayoutPanel6.PerformLayout()
        TableLayoutPanel11.ResumeLayout(False)
        TableLayoutPanel11.PerformLayout()
        TableLayoutPanel17.ResumeLayout(False)
        TableLayoutPanel18.ResumeLayout(False)
        TableLayoutPanel18.PerformLayout()
        ResumeLayout(False)
    End Sub



    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents customerslbl As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label12 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents Label7 As Label
    Friend WithEvents contactbox As TextBox
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents Label5 As Label
    Friend WithEvents addressbox As TextBox
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents lnamebox As TextBox
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents fnamebox As TextBox
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents addbtn2 As Button
    Friend WithEvents clearbtn2 As Button
    Friend WithEvents deletebtn2 As Button
    Friend WithEvents editbtn2 As Button
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents Label14 As Label
    Friend WithEvents customerListView As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader


End Class
