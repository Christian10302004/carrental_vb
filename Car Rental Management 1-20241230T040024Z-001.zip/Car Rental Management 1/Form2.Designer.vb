﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel8 = New TableLayoutPanel()
        Label6 = New Label()
        PictureBox6 = New PictureBox()
        TableLayoutPanel7 = New TableLayoutPanel()
        customerslbl = New Label()
        PictureBox5 = New PictureBox()
        TableLayoutPanel5 = New TableLayoutPanel()
        Label12 = New Label()
        PictureBox2 = New PictureBox()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        TableLayoutPanel9 = New TableLayoutPanel()
        TableLayoutPanel16 = New TableLayoutPanel()
        Label13 = New Label()
        availcbb = New ComboBox()
        TableLayoutPanel15 = New TableLayoutPanel()
        pricebox = New TextBox()
        Label10 = New Label()
        TableLayoutPanel14 = New TableLayoutPanel()
        Label9 = New Label()
        colorbox = New TextBox()
        TableLayoutPanel12 = New TableLayoutPanel()
        modelbox = New TextBox()
        Label8 = New Label()
        TableLayoutPanel11 = New TableLayoutPanel()
        Label4 = New Label()
        regbox = New TextBox()
        TableLayoutPanel10 = New TableLayoutPanel()
        brandcbb = New ComboBox()
        Label7 = New Label()
        TableLayoutPanel17 = New TableLayoutPanel()
        addbtn1 = New Button()
        clearbtn1 = New Button()
        deletebtn1 = New Button()
        editbtn1 = New Button()
        TableLayoutPanel18 = New TableLayoutPanel()
        Label14 = New Label()
        carlist = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        ColumnHeader6 = New ColumnHeader()
        ColumnHeader7 = New ColumnHeader()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel8.SuspendLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel7.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel5.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel9.SuspendLayout()
        TableLayoutPanel16.SuspendLayout()
        TableLayoutPanel15.SuspendLayout()
        TableLayoutPanel14.SuspendLayout()
        TableLayoutPanel12.SuspendLayout()
        TableLayoutPanel11.SuspendLayout()
        TableLayoutPanel10.SuspendLayout()
        TableLayoutPanel17.SuspendLayout()
        TableLayoutPanel18.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel9, 0, 2)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel17, 0, 3)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel18, 0, 4)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 5
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 8F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 9F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 26F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 7F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel1.Size = New Size(934, 611)
        TableLayoutPanel1.TabIndex = 1
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.BackColor = Color.White
        TableLayoutPanel2.ColumnCount = 2
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 5F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 95F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 0)
        TableLayoutPanel2.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 3)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(928, 42)
        TableLayoutPanel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(49, 10)
        Label2.Name = "Label2"
        Label2.Size = New Size(102, 21)
        Label2.TabIndex = 21
        Label2.Text = "CAR RENTAL"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(10, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 33)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.BackColor = Color.White
        TableLayoutPanel3.ColumnCount = 4
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel8, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel7, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel5, 1, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 51)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(928, 48)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' TableLayoutPanel8
        ' 
        TableLayoutPanel8.ColumnCount = 2
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.Controls.Add(Label6, 0, 0)
        TableLayoutPanel8.Controls.Add(PictureBox6, 0, 0)
        TableLayoutPanel8.Dock = DockStyle.Fill
        TableLayoutPanel8.Location = New Point(466, 3)
        TableLayoutPanel8.Name = "TableLayoutPanel8"
        TableLayoutPanel8.RowCount = 1
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel8.Size = New Size(179, 42)
        TableLayoutPanel8.TabIndex = 3
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(92, 8)
        Label6.Name = "Label6"
        Label6.Size = New Size(59, 25)
        Label6.TabIndex = 23
        Label6.Text = "RENT"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Anchor = AnchorStyles.Right
        PictureBox6.Image = My.Resources.Resources.car__1_
        PictureBox6.Location = New Point(53, 4)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(33, 33)
        PictureBox6.TabIndex = 22
        PictureBox6.TabStop = False
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 2
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel7.Controls.Add(customerslbl, 0, 0)
        TableLayoutPanel7.Controls.Add(PictureBox5, 0, 0)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(281, 3)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 1
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel7.Size = New Size(179, 42)
        TableLayoutPanel7.TabIndex = 2
        ' 
        ' customerslbl
        ' 
        customerslbl.Anchor = AnchorStyles.Left
        customerslbl.AutoSize = True
        customerslbl.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        customerslbl.Location = New Point(56, 8)
        customerslbl.Name = "customerslbl"
        customerslbl.Size = New Size(120, 25)
        customerslbl.TabIndex = 26
        customerslbl.Text = "CUSTOMERS"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Right
        PictureBox5.Image = My.Resources.Resources.rating
        PictureBox5.Location = New Point(17, 4)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 33)
        PictureBox5.TabIndex = 25
        PictureBox5.TabStop = False
        ' 
        ' TableLayoutPanel5
        ' 
        TableLayoutPanel5.ColumnCount = 2
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel5.Controls.Add(Label12, 0, 0)
        TableLayoutPanel5.Controls.Add(PictureBox2, 0, 0)
        TableLayoutPanel5.Dock = DockStyle.Fill
        TableLayoutPanel5.Location = New Point(651, 3)
        TableLayoutPanel5.Name = "TableLayoutPanel5"
        TableLayoutPanel5.RowCount = 1
        TableLayoutPanel5.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel5.Size = New Size(274, 42)
        TableLayoutPanel5.TabIndex = 1
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Left
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(85, 8)
        Label12.Name = "Label12"
        Label12.Size = New Size(136, 25)
        Label12.TabIndex = 24
        Label12.Text = "RETURN CARS"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Right
        PictureBox2.Image = My.Resources.Resources._return
        PictureBox2.Location = New Point(46, 4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(33, 33)
        PictureBox2.TabIndex = 23
        PictureBox2.TabStop = False
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel4.Controls.Add(Label3, 1, 0)
        TableLayoutPanel4.Dock = DockStyle.Fill
        TableLayoutPanel4.Location = New Point(3, 3)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Size = New Size(272, 42)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.car
        PictureBox3.Location = New Point(100, 4)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(33, 33)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Left
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(139, 8)
        Label3.Name = "Label3"
        Label3.Size = New Size(59, 25)
        Label3.TabIndex = 21
        Label3.Text = "CARS"
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel9.ColumnCount = 3
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.Controls.Add(TableLayoutPanel16, 2, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel15, 1, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel14, 0, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel12, 2, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel11, 0, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel10, 1, 0)
        TableLayoutPanel9.Dock = DockStyle.Fill
        TableLayoutPanel9.Location = New Point(3, 105)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 2
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.Size = New Size(928, 152)
        TableLayoutPanel9.TabIndex = 2
        ' 
        ' TableLayoutPanel16
        ' 
        TableLayoutPanel16.BackColor = Color.White
        TableLayoutPanel16.ColumnCount = 1
        TableLayoutPanel16.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Controls.Add(Label13, 0, 0)
        TableLayoutPanel16.Controls.Add(availcbb, 0, 1)
        TableLayoutPanel16.Dock = DockStyle.Fill
        TableLayoutPanel16.Location = New Point(605, 79)
        TableLayoutPanel16.Name = "TableLayoutPanel16"
        TableLayoutPanel16.RowCount = 2
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Size = New Size(320, 70)
        TableLayoutPanel16.TabIndex = 6
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Bottom
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(107, 10)
        Label13.Name = "Label13"
        Label13.Size = New Size(106, 25)
        Label13.TabIndex = 17
        Label13.Text = "AVAILABLE"
        ' 
        ' availcbb
        ' 
        availcbb.Anchor = AnchorStyles.Top
        availcbb.DropDownStyle = ComboBoxStyle.DropDownList
        availcbb.Font = New Font("Segoe UI", 12F)
        availcbb.FormattingEnabled = True
        availcbb.Location = New Point(95, 38)
        availcbb.Name = "availcbb"
        availcbb.Size = New Size(130, 29)
        availcbb.TabIndex = 6
        ' 
        ' TableLayoutPanel15
        ' 
        TableLayoutPanel15.BackColor = Color.White
        TableLayoutPanel15.ColumnCount = 1
        TableLayoutPanel15.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Controls.Add(pricebox, 0, 1)
        TableLayoutPanel15.Controls.Add(Label10, 0, 0)
        TableLayoutPanel15.Dock = DockStyle.Fill
        TableLayoutPanel15.Location = New Point(327, 79)
        TableLayoutPanel15.Name = "TableLayoutPanel15"
        TableLayoutPanel15.RowCount = 2
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Size = New Size(272, 70)
        TableLayoutPanel15.TabIndex = 5
        ' 
        ' pricebox
        ' 
        pricebox.Anchor = AnchorStyles.Top
        pricebox.Font = New Font("Segoe UI", 12F)
        pricebox.Location = New Point(71, 38)
        pricebox.Name = "pricebox"
        pricebox.Size = New Size(130, 29)
        pricebox.TabIndex = 5
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Bottom
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(104, 10)
        Label10.Name = "Label10"
        Label10.Size = New Size(63, 25)
        Label10.TabIndex = 10
        Label10.Text = "PRICE"
        ' 
        ' TableLayoutPanel14
        ' 
        TableLayoutPanel14.BackColor = Color.White
        TableLayoutPanel14.ColumnCount = 1
        TableLayoutPanel14.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Controls.Add(Label9, 0, 0)
        TableLayoutPanel14.Controls.Add(colorbox, 0, 1)
        TableLayoutPanel14.Dock = DockStyle.Fill
        TableLayoutPanel14.Location = New Point(3, 79)
        TableLayoutPanel14.Name = "TableLayoutPanel14"
        TableLayoutPanel14.RowCount = 2
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Size = New Size(318, 70)
        TableLayoutPanel14.TabIndex = 4
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Bottom
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(123, 10)
        Label9.Name = "Label9"
        Label9.Size = New Size(72, 25)
        Label9.TabIndex = 16
        Label9.Text = "COLOR"
        ' 
        ' colorbox
        ' 
        colorbox.Anchor = AnchorStyles.Top
        colorbox.Font = New Font("Segoe UI", 12F)
        colorbox.Location = New Point(94, 38)
        colorbox.Name = "colorbox"
        colorbox.Size = New Size(130, 29)
        colorbox.TabIndex = 4
        ' 
        ' TableLayoutPanel12
        ' 
        TableLayoutPanel12.BackColor = Color.White
        TableLayoutPanel12.ColumnCount = 1
        TableLayoutPanel12.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Controls.Add(modelbox, 0, 1)
        TableLayoutPanel12.Controls.Add(Label8, 0, 0)
        TableLayoutPanel12.Dock = DockStyle.Fill
        TableLayoutPanel12.Location = New Point(605, 3)
        TableLayoutPanel12.Name = "TableLayoutPanel12"
        TableLayoutPanel12.RowCount = 2
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Size = New Size(320, 70)
        TableLayoutPanel12.TabIndex = 3
        ' 
        ' modelbox
        ' 
        modelbox.Anchor = AnchorStyles.Top
        modelbox.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        modelbox.Location = New Point(95, 38)
        modelbox.Name = "modelbox"
        modelbox.Size = New Size(130, 29)
        modelbox.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Bottom
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(119, 10)
        Label8.Name = "Label8"
        Label8.Size = New Size(82, 25)
        Label8.TabIndex = 8
        Label8.Text = " MODEL"
        ' 
        ' TableLayoutPanel11
        ' 
        TableLayoutPanel11.BackColor = Color.White
        TableLayoutPanel11.ColumnCount = 1
        TableLayoutPanel11.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Controls.Add(Label4, 0, 0)
        TableLayoutPanel11.Controls.Add(regbox, 0, 1)
        TableLayoutPanel11.Dock = DockStyle.Fill
        TableLayoutPanel11.Location = New Point(3, 3)
        TableLayoutPanel11.Name = "TableLayoutPanel11"
        TableLayoutPanel11.RowCount = 2
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Size = New Size(318, 70)
        TableLayoutPanel11.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(93, 10)
        Label4.Name = "Label4"
        Label4.Size = New Size(131, 25)
        Label4.TabIndex = 6
        Label4.Text = "REG NUMBER"
        ' 
        ' regbox
        ' 
        regbox.Anchor = AnchorStyles.Top
        regbox.Font = New Font("Segoe UI", 12F)
        regbox.Location = New Point(94, 38)
        regbox.Name = "regbox"
        regbox.Size = New Size(130, 29)
        regbox.TabIndex = 0
        ' 
        ' TableLayoutPanel10
        ' 
        TableLayoutPanel10.BackColor = Color.White
        TableLayoutPanel10.ColumnCount = 1
        TableLayoutPanel10.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Controls.Add(brandcbb, 0, 1)
        TableLayoutPanel10.Controls.Add(Label7, 0, 0)
        TableLayoutPanel10.Dock = DockStyle.Fill
        TableLayoutPanel10.Location = New Point(327, 3)
        TableLayoutPanel10.Name = "TableLayoutPanel10"
        TableLayoutPanel10.RowCount = 2
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Size = New Size(272, 70)
        TableLayoutPanel10.TabIndex = 2
        ' 
        ' brandcbb
        ' 
        brandcbb.Anchor = AnchorStyles.Top
        brandcbb.DropDownStyle = ComboBoxStyle.DropDownList
        brandcbb.Font = New Font("Segoe UI", 12F)
        brandcbb.FormattingEnabled = True
        brandcbb.Location = New Point(71, 38)
        brandcbb.Name = "brandcbb"
        brandcbb.Size = New Size(130, 29)
        brandcbb.TabIndex = 2
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Bottom
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(97, 10)
        Label7.Name = "Label7"
        Label7.Size = New Size(77, 25)
        Label7.TabIndex = 7
        Label7.Text = "BRAND"
        ' 
        ' TableLayoutPanel17
        ' 
        TableLayoutPanel17.BackColor = Color.White
        TableLayoutPanel17.ColumnCount = 4
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.Controls.Add(addbtn1, 0, 0)
        TableLayoutPanel17.Controls.Add(clearbtn1, 3, 0)
        TableLayoutPanel17.Controls.Add(deletebtn1, 2, 0)
        TableLayoutPanel17.Controls.Add(editbtn1, 1, 0)
        TableLayoutPanel17.Dock = DockStyle.Fill
        TableLayoutPanel17.Location = New Point(3, 263)
        TableLayoutPanel17.Name = "TableLayoutPanel17"
        TableLayoutPanel17.RowCount = 1
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel17.Size = New Size(928, 36)
        TableLayoutPanel17.TabIndex = 3
        ' 
        ' addbtn1
        ' 
        addbtn1.Anchor = AnchorStyles.Right
        addbtn1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        addbtn1.Location = New Point(175, 3)
        addbtn1.Name = "addbtn1"
        addbtn1.Size = New Size(100, 30)
        addbtn1.TabIndex = 7
        addbtn1.Text = "ADD"
        addbtn1.UseVisualStyleBackColor = True
        ' 
        ' clearbtn1
        ' 
        clearbtn1.Anchor = AnchorStyles.Left
        clearbtn1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        clearbtn1.Location = New Point(651, 3)
        clearbtn1.Name = "clearbtn1"
        clearbtn1.Size = New Size(100, 30)
        clearbtn1.TabIndex = 10
        clearbtn1.Text = "CLEAR"
        clearbtn1.UseVisualStyleBackColor = True
        ' 
        ' deletebtn1
        ' 
        deletebtn1.Anchor = AnchorStyles.None
        deletebtn1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        deletebtn1.Location = New Point(505, 3)
        deletebtn1.Name = "deletebtn1"
        deletebtn1.Size = New Size(100, 30)
        deletebtn1.TabIndex = 9
        deletebtn1.Text = "DELETE"
        deletebtn1.UseVisualStyleBackColor = True
        ' 
        ' editbtn1
        ' 
        editbtn1.Anchor = AnchorStyles.None
        editbtn1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        editbtn1.Location = New Point(320, 3)
        editbtn1.Name = "editbtn1"
        editbtn1.Size = New Size(100, 30)
        editbtn1.TabIndex = 8
        editbtn1.Text = "EDIT"
        editbtn1.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel18
        ' 
        TableLayoutPanel18.BackColor = Color.White
        TableLayoutPanel18.ColumnCount = 1
        TableLayoutPanel18.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel18.Controls.Add(Label14, 0, 0)
        TableLayoutPanel18.Controls.Add(carlist, 0, 1)
        TableLayoutPanel18.Dock = DockStyle.Fill
        TableLayoutPanel18.Location = New Point(3, 305)
        TableLayoutPanel18.Name = "TableLayoutPanel18"
        TableLayoutPanel18.RowCount = 2
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 12F))
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 88F))
        TableLayoutPanel18.Size = New Size(928, 303)
        TableLayoutPanel18.TabIndex = 4
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.None
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(418, 5)
        Label14.Name = "Label14"
        Label14.Size = New Size(92, 25)
        Label14.TabIndex = 17
        Label14.Text = "CAR LIST"
        ' 
        ' carlist
        ' 
        carlist.BorderStyle = BorderStyle.FixedSingle
        carlist.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5, ColumnHeader6, ColumnHeader7})
        carlist.Dock = DockStyle.Fill
        carlist.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        carlist.GridLines = True
        carlist.Location = New Point(3, 39)
        carlist.Name = "carlist"
        carlist.Size = New Size(922, 261)
        carlist.TabIndex = 11
        carlist.UseCompatibleStateImageBehavior = False
        carlist.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "CAR ID"
        ColumnHeader1.Width = 100
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "REG NUMBER"
        ColumnHeader2.TextAlign = HorizontalAlignment.Center
        ColumnHeader2.Width = 150
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "BRAND"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 150
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "MODEL"
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 100
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "COLOR"
        ColumnHeader5.TextAlign = HorizontalAlignment.Center
        ColumnHeader5.Width = 150
        ' 
        ' ColumnHeader6
        ' 
        ColumnHeader6.Text = "PRICE"
        ColumnHeader6.TextAlign = HorizontalAlignment.Center
        ColumnHeader6.Width = 150
        ' 
        ' ColumnHeader7
        ' 
        ColumnHeader7.Text = "AVAILABLE"
        ColumnHeader7.TextAlign = HorizontalAlignment.Center
        ColumnHeader7.Width = 130
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(934, 611)
        Controls.Add(TableLayoutPanel1)
        Name = "Form2"
        Text = "CARS"
        WindowState = FormWindowState.Maximized
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel8.ResumeLayout(False)
        TableLayoutPanel8.PerformLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel7.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel5.ResumeLayout(False)
        TableLayoutPanel5.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel9.ResumeLayout(False)
        TableLayoutPanel16.ResumeLayout(False)
        TableLayoutPanel16.PerformLayout()
        TableLayoutPanel15.ResumeLayout(False)
        TableLayoutPanel15.PerformLayout()
        TableLayoutPanel14.ResumeLayout(False)
        TableLayoutPanel14.PerformLayout()
        TableLayoutPanel12.ResumeLayout(False)
        TableLayoutPanel12.PerformLayout()
        TableLayoutPanel11.ResumeLayout(False)
        TableLayoutPanel11.PerformLayout()
        TableLayoutPanel10.ResumeLayout(False)
        TableLayoutPanel10.PerformLayout()
        TableLayoutPanel17.ResumeLayout(False)
        TableLayoutPanel18.ResumeLayout(False)
        TableLayoutPanel18.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents customerslbl As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label12 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel16 As TableLayoutPanel
    Friend WithEvents Label13 As Label
    Friend WithEvents availcbb As ComboBox
    Friend WithEvents TableLayoutPanel15 As TableLayoutPanel
    Friend WithEvents pricebox As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TableLayoutPanel14 As TableLayoutPanel
    Friend WithEvents Label9 As Label
    Friend WithEvents colorbox As TextBox
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents modelbox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents regbox As TextBox
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents Label7 As Label
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents clearbtn1 As Button
    Friend WithEvents deletebtn1 As Button
    Friend WithEvents editbtn1 As Button
    Friend WithEvents addbtn1 As Button
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents Label14 As Label
    Friend WithEvents carlist As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents ColumnHeader7 As ColumnHeader
    Friend WithEvents brandcbb As ComboBox
End Class
