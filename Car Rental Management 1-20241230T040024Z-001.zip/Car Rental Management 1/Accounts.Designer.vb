﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Accounts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel6 = New TableLayoutPanel()
        backbtn = New Button()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel7 = New TableLayoutPanel()
        customerslbl = New Label()
        PictureBox5 = New PictureBox()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        TableLayoutPanel9 = New TableLayoutPanel()
        TableLayoutPanel12 = New TableLayoutPanel()
        password = New TextBox()
        Label8 = New Label()
        TableLayoutPanel11 = New TableLayoutPanel()
        Label4 = New Label()
        employeecbb = New ComboBox()
        TableLayoutPanel10 = New TableLayoutPanel()
        username = New TextBox()
        Label7 = New Label()
        TableLayoutPanel17 = New TableLayoutPanel()
        addbtn1 = New Button()
        clearbtn1 = New Button()
        deletebtn1 = New Button()
        editbtn1 = New Button()
        TableLayoutPanel18 = New TableLayoutPanel()
        Label14 = New Label()
        accountlistview = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel6.SuspendLayout()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel7.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel9.SuspendLayout()
        TableLayoutPanel12.SuspendLayout()
        TableLayoutPanel11.SuspendLayout()
        TableLayoutPanel10.SuspendLayout()
        TableLayoutPanel17.SuspendLayout()
        TableLayoutPanel18.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel9, 0, 2)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel17, 0, 3)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel18, 0, 4)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 5
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 8F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 9F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 26F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 47F))
        TableLayoutPanel1.Size = New Size(944, 561)
        TableLayoutPanel1.TabIndex = 3
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.BackColor = Color.White
        TableLayoutPanel2.ColumnCount = 3
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 5F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 85F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 10F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 0)
        TableLayoutPanel2.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel2.Controls.Add(TableLayoutPanel6, 2, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 3)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(938, 38)
        TableLayoutPanel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(49, 6)
        Label2.Name = "Label2"
        Label2.Size = New Size(122, 25)
        Label2.TabIndex = 21
        Label2.Text = "CAR RENTAL"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(10, 3)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 32)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel6
        ' 
        TableLayoutPanel6.ColumnCount = 1
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Controls.Add(backbtn, 0, 0)
        TableLayoutPanel6.Dock = DockStyle.Fill
        TableLayoutPanel6.Location = New Point(846, 3)
        TableLayoutPanel6.Name = "TableLayoutPanel6"
        TableLayoutPanel6.RowCount = 1
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel6.Size = New Size(89, 32)
        TableLayoutPanel6.TabIndex = 22
        ' 
        ' backbtn
        ' 
        backbtn.Dock = DockStyle.Fill
        backbtn.Location = New Point(3, 3)
        backbtn.Name = "backbtn"
        backbtn.Size = New Size(83, 26)
        backbtn.TabIndex = 0
        backbtn.Text = "BACK"
        backbtn.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.BackColor = Color.White
        TableLayoutPanel3.ColumnCount = 2
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 33.3333321F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 33.3333321F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel7, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 47)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(938, 44)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 2
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.Controls.Add(customerslbl, 0, 0)
        TableLayoutPanel7.Controls.Add(PictureBox5, 0, 0)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(472, 3)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 1
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel7.Size = New Size(463, 38)
        TableLayoutPanel7.TabIndex = 2
        ' 
        ' customerslbl
        ' 
        customerslbl.Anchor = AnchorStyles.Left
        customerslbl.AutoSize = True
        customerslbl.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        customerslbl.Location = New Point(234, 6)
        customerslbl.Name = "customerslbl"
        customerslbl.Size = New Size(110, 25)
        customerslbl.TabIndex = 26
        customerslbl.Text = "ACCOUNTS"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Right
        PictureBox5.Image = My.Resources.Resources.id_card__1_
        PictureBox5.Location = New Point(195, 3)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 32)
        PictureBox5.TabIndex = 25
        PictureBox5.TabStop = False
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel4.Controls.Add(Label3, 1, 0)
        TableLayoutPanel4.Dock = DockStyle.Fill
        TableLayoutPanel4.Location = New Point(3, 3)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Size = New Size(463, 38)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.employees__1_
        PictureBox3.Location = New Point(195, 3)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(33, 32)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Left
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(234, 6)
        Label3.Name = "Label3"
        Label3.Size = New Size(114, 25)
        Label3.TabIndex = 21
        Label3.Text = "EMPLOYEES"
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel9.ColumnCount = 3
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35F))
        TableLayoutPanel9.Controls.Add(TableLayoutPanel12, 2, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel11, 0, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel10, 1, 0)
        TableLayoutPanel9.Dock = DockStyle.Fill
        TableLayoutPanel9.Location = New Point(3, 97)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 1
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.Size = New Size(938, 139)
        TableLayoutPanel9.TabIndex = 2
        ' 
        ' TableLayoutPanel12
        ' 
        TableLayoutPanel12.BackColor = Color.White
        TableLayoutPanel12.ColumnCount = 1
        TableLayoutPanel12.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Controls.Add(password, 0, 1)
        TableLayoutPanel12.Controls.Add(Label8, 0, 0)
        TableLayoutPanel12.Dock = DockStyle.Fill
        TableLayoutPanel12.Location = New Point(612, 3)
        TableLayoutPanel12.Name = "TableLayoutPanel12"
        TableLayoutPanel12.RowCount = 2
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Size = New Size(323, 133)
        TableLayoutPanel12.TabIndex = 3
        ' 
        ' password
        ' 
        password.Anchor = AnchorStyles.Top
        password.Font = New Font("Segoe UI", 12F)
        password.Location = New Point(96, 69)
        password.Name = "password"
        password.Size = New Size(130, 29)
        password.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Bottom
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(105, 41)
        Label8.Name = "Label8"
        Label8.Size = New Size(113, 25)
        Label8.TabIndex = 8
        Label8.Text = "PASSWORD"
        ' 
        ' TableLayoutPanel11
        ' 
        TableLayoutPanel11.BackColor = Color.White
        TableLayoutPanel11.ColumnCount = 1
        TableLayoutPanel11.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Controls.Add(Label4, 0, 0)
        TableLayoutPanel11.Controls.Add(employeecbb, 0, 1)
        TableLayoutPanel11.Dock = DockStyle.Fill
        TableLayoutPanel11.Location = New Point(3, 3)
        TableLayoutPanel11.Name = "TableLayoutPanel11"
        TableLayoutPanel11.RowCount = 2
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Size = New Size(322, 133)
        TableLayoutPanel11.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(96, 41)
        Label4.Name = "Label4"
        Label4.Size = New Size(129, 25)
        Label4.TabIndex = 6
        Label4.Text = "EMPLOYEE ID"
        ' 
        ' employeecbb
        ' 
        employeecbb.Anchor = AnchorStyles.Top
        employeecbb.DropDownStyle = ComboBoxStyle.DropDownList
        employeecbb.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        employeecbb.FormattingEnabled = True
        employeecbb.Location = New Point(96, 69)
        employeecbb.Name = "employeecbb"
        employeecbb.Size = New Size(130, 29)
        employeecbb.TabIndex = 7
        ' 
        ' TableLayoutPanel10
        ' 
        TableLayoutPanel10.BackColor = Color.White
        TableLayoutPanel10.ColumnCount = 1
        TableLayoutPanel10.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Controls.Add(username, 0, 1)
        TableLayoutPanel10.Controls.Add(Label7, 0, 0)
        TableLayoutPanel10.Dock = DockStyle.Fill
        TableLayoutPanel10.Location = New Point(331, 3)
        TableLayoutPanel10.Name = "TableLayoutPanel10"
        TableLayoutPanel10.RowCount = 2
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Size = New Size(275, 133)
        TableLayoutPanel10.TabIndex = 2
        ' 
        ' username
        ' 
        username.Anchor = AnchorStyles.Top
        username.Font = New Font("Segoe UI", 12F)
        username.Location = New Point(72, 69)
        username.Name = "username"
        username.Size = New Size(130, 29)
        username.TabIndex = 8
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Bottom
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(81, 41)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 25)
        Label7.TabIndex = 7
        Label7.Text = "USERNAME"
        ' 
        ' TableLayoutPanel17
        ' 
        TableLayoutPanel17.BackColor = Color.White
        TableLayoutPanel17.ColumnCount = 4
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel17.Controls.Add(addbtn1, 0, 0)
        TableLayoutPanel17.Controls.Add(clearbtn1, 3, 0)
        TableLayoutPanel17.Controls.Add(deletebtn1, 2, 0)
        TableLayoutPanel17.Controls.Add(editbtn1, 1, 0)
        TableLayoutPanel17.Dock = DockStyle.Fill
        TableLayoutPanel17.Location = New Point(3, 242)
        TableLayoutPanel17.Name = "TableLayoutPanel17"
        TableLayoutPanel17.RowCount = 1
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel17.Size = New Size(938, 50)
        TableLayoutPanel17.TabIndex = 3
        ' 
        ' addbtn1
        ' 
        addbtn1.Anchor = AnchorStyles.Right
        addbtn1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        addbtn1.Location = New Point(178, 10)
        addbtn1.Name = "addbtn1"
        addbtn1.Size = New Size(100, 30)
        addbtn1.TabIndex = 7
        addbtn1.Text = "ADD"
        addbtn1.TextAlign = ContentAlignment.TopCenter
        addbtn1.UseVisualStyleBackColor = True
        ' 
        ' clearbtn1
        ' 
        clearbtn1.Anchor = AnchorStyles.Left
        clearbtn1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        clearbtn1.Location = New Point(658, 10)
        clearbtn1.Name = "clearbtn1"
        clearbtn1.Size = New Size(100, 30)
        clearbtn1.TabIndex = 10
        clearbtn1.Text = "CLEAR"
        clearbtn1.TextAlign = ContentAlignment.TopCenter
        clearbtn1.UseVisualStyleBackColor = True
        ' 
        ' deletebtn1
        ' 
        deletebtn1.Anchor = AnchorStyles.None
        deletebtn1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        deletebtn1.Location = New Point(511, 10)
        deletebtn1.Name = "deletebtn1"
        deletebtn1.Size = New Size(100, 30)
        deletebtn1.TabIndex = 9
        deletebtn1.Text = "DELETE"
        deletebtn1.TextAlign = ContentAlignment.TopCenter
        deletebtn1.UseVisualStyleBackColor = True
        ' 
        ' editbtn1
        ' 
        editbtn1.Anchor = AnchorStyles.None
        editbtn1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        editbtn1.Location = New Point(324, 10)
        editbtn1.Name = "editbtn1"
        editbtn1.Size = New Size(100, 30)
        editbtn1.TabIndex = 8
        editbtn1.Text = "EDIT"
        editbtn1.TextAlign = ContentAlignment.TopCenter
        editbtn1.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel18
        ' 
        TableLayoutPanel18.BackColor = Color.White
        TableLayoutPanel18.ColumnCount = 1
        TableLayoutPanel18.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel18.Controls.Add(Label14, 0, 0)
        TableLayoutPanel18.Controls.Add(accountlistview, 0, 1)
        TableLayoutPanel18.Dock = DockStyle.Fill
        TableLayoutPanel18.Location = New Point(3, 298)
        TableLayoutPanel18.Name = "TableLayoutPanel18"
        TableLayoutPanel18.RowCount = 2
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 12F))
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 88F))
        TableLayoutPanel18.Size = New Size(938, 260)
        TableLayoutPanel18.TabIndex = 4
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.None
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(419, 3)
        Label14.Name = "Label14"
        Label14.Size = New Size(100, 25)
        Label14.TabIndex = 17
        Label14.Text = "ACCOUNT"
        ' 
        ' accountlistview
        ' 
        accountlistview.BorderStyle = BorderStyle.FixedSingle
        accountlistview.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4})
        accountlistview.Dock = DockStyle.Fill
        accountlistview.Font = New Font("Segoe UI", 11F)
        accountlistview.GridLines = True
        accountlistview.Location = New Point(3, 34)
        accountlistview.Name = "accountlistview"
        accountlistview.Size = New Size(932, 223)
        accountlistview.TabIndex = 11
        accountlistview.UseCompatibleStateImageBehavior = False
        accountlistview.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "ACCOUNT ID"
        ColumnHeader1.Width = 250
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "EMPLOYEES ID"
        ColumnHeader2.TextAlign = HorizontalAlignment.Center
        ColumnHeader2.Width = 250
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "USERNAME"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 250
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "PASSWORD"
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 200
        ' 
        ' Accounts
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(944, 561)
        Controls.Add(TableLayoutPanel1)
        Name = "Accounts"
        Text = "Accounts"
        WindowState = FormWindowState.Maximized
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel6.ResumeLayout(False)
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel7.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel9.ResumeLayout(False)
        TableLayoutPanel12.ResumeLayout(False)
        TableLayoutPanel12.PerformLayout()
        TableLayoutPanel11.ResumeLayout(False)
        TableLayoutPanel11.PerformLayout()
        TableLayoutPanel10.ResumeLayout(False)
        TableLayoutPanel10.PerformLayout()
        TableLayoutPanel17.ResumeLayout(False)
        TableLayoutPanel18.ResumeLayout(False)
        TableLayoutPanel18.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents customerslbl As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents password As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents employeecbb As ComboBox
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents username As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents addbtn1 As Button
    Friend WithEvents clearbtn1 As Button
    Friend WithEvents deletebtn1 As Button
    Friend WithEvents editbtn1 As Button
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents Label14 As Label
    Friend WithEvents accountlistview As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents backbtn As Button
End Class
