﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        admintxt = New TextBox()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel6 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox3 = New PictureBox()
        TableLayoutPanel2 = New TableLayoutPanel()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox1 = New PictureBox()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel5 = New TableLayoutPanel()
        PictureBox2 = New PictureBox()
        passtxt = New TextBox()
        TableLayoutPanel7 = New TableLayoutPanel()
        TableLayoutPanel8 = New TableLayoutPanel()
        adminlog = New Button()
        TableLayoutPanel9 = New TableLayoutPanel()
        Button1 = New Button()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel6.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel2.SuspendLayout()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel5.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel7.SuspendLayout()
        TableLayoutPanel8.SuspendLayout()
        TableLayoutPanel9.SuspendLayout()
        SuspendLayout()
        ' 
        ' admintxt
        ' 
        admintxt.Anchor = AnchorStyles.Left
        admintxt.BorderStyle = BorderStyle.None
        admintxt.Font = New Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        admintxt.Location = New Point(46, 8)
        admintxt.Name = "admintxt"
        admintxt.PlaceholderText = "Username"
        admintxt.Size = New Size(150, 27)
        admintxt.TabIndex = 0
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel6, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 2)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel7, 0, 3)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 4
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 22F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 22F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 22F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 34F))
        TableLayoutPanel1.Size = New Size(484, 261)
        TableLayoutPanel1.TabIndex = 5
        ' 
        ' TableLayoutPanel6
        ' 
        TableLayoutPanel6.BackColor = Color.White
        TableLayoutPanel6.ColumnCount = 2
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40F))
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 60F))
        TableLayoutPanel6.Controls.Add(Label2, 0, 0)
        TableLayoutPanel6.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel6.Dock = DockStyle.Fill
        TableLayoutPanel6.Location = New Point(3, 3)
        TableLayoutPanel6.Name = "TableLayoutPanel6"
        TableLayoutPanel6.RowCount = 1
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel6.Size = New Size(478, 51)
        TableLayoutPanel6.TabIndex = 7
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(194, 13)
        Label2.Name = "Label2"
        Label2.Size = New Size(122, 25)
        Label2.TabIndex = 21
        Label2.Text = "CAR RENTAL"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.LOGO1
        PictureBox3.Location = New Point(148, 5)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(40, 40)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.ColumnCount = 1
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40F))
        TableLayoutPanel2.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 60)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(478, 51)
        TableLayoutPanel2.TabIndex = 5
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.Anchor = AnchorStyles.None
        TableLayoutPanel4.BackColor = Color.White
        TableLayoutPanel4.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 21F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 79F))
        TableLayoutPanel4.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel4.Controls.Add(admintxt, 1, 0)
        TableLayoutPanel4.Location = New Point(139, 4)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel4.Size = New Size(200, 43)
        TableLayoutPanel4.TabIndex = 7
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImage = My.Resources.Resources.user2
        PictureBox1.Dock = DockStyle.Fill
        PictureBox1.Location = New Point(4, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(35, 35)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.ColumnCount = 1
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel5, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 117)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(478, 51)
        TableLayoutPanel3.TabIndex = 6
        ' 
        ' TableLayoutPanel5
        ' 
        TableLayoutPanel5.Anchor = AnchorStyles.None
        TableLayoutPanel5.BackColor = Color.White
        TableLayoutPanel5.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel5.ColumnCount = 2
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 21F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 79F))
        TableLayoutPanel5.Controls.Add(PictureBox2, 0, 0)
        TableLayoutPanel5.Controls.Add(passtxt, 1, 0)
        TableLayoutPanel5.Location = New Point(139, 4)
        TableLayoutPanel5.Name = "TableLayoutPanel5"
        TableLayoutPanel5.RowCount = 1
        TableLayoutPanel5.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel5.Size = New Size(200, 43)
        TableLayoutPanel5.TabIndex = 7
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.BackgroundImage = My.Resources.Resources.padlock1
        PictureBox2.Dock = DockStyle.Fill
        PictureBox2.Location = New Point(4, 4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(35, 35)
        PictureBox2.TabIndex = 2
        PictureBox2.TabStop = False
        ' 
        ' passtxt
        ' 
        passtxt.Anchor = AnchorStyles.Left
        passtxt.BorderStyle = BorderStyle.None
        passtxt.Font = New Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        passtxt.Location = New Point(46, 8)
        passtxt.Name = "passtxt"
        passtxt.PasswordChar = "*"c
        passtxt.PlaceholderText = "Password"
        passtxt.Size = New Size(150, 27)
        passtxt.TabIndex = 1
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 1
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.Controls.Add(TableLayoutPanel8, 0, 0)
        TableLayoutPanel7.Controls.Add(TableLayoutPanel9, 0, 1)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(3, 174)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 2
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel7.Size = New Size(478, 84)
        TableLayoutPanel7.TabIndex = 8
        ' 
        ' TableLayoutPanel8
        ' 
        TableLayoutPanel8.Anchor = AnchorStyles.None
        TableLayoutPanel8.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel8.ColumnCount = 1
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.Controls.Add(adminlog, 0, 0)
        TableLayoutPanel8.Location = New Point(189, 3)
        TableLayoutPanel8.Name = "TableLayoutPanel8"
        TableLayoutPanel8.RowCount = 1
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.Size = New Size(100, 36)
        TableLayoutPanel8.TabIndex = 0
        ' 
        ' adminlog
        ' 
        adminlog.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        adminlog.Location = New Point(3, 3)
        adminlog.Name = "adminlog"
        adminlog.Size = New Size(94, 28)
        adminlog.TabIndex = 0
        adminlog.Text = "LOG IN"
        adminlog.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.Anchor = AnchorStyles.None
        TableLayoutPanel9.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel9.ColumnCount = 1
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.Controls.Add(Button1, 0, 0)
        TableLayoutPanel9.Location = New Point(189, 45)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 1
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel9.Size = New Size(100, 35)
        TableLayoutPanel9.TabIndex = 1
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(3, 3)
        Button1.Name = "Button1"
        Button1.Size = New Size(94, 29)
        Button1.TabIndex = 0
        Button1.Text = "ADMIN"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(484, 261)
        Controls.Add(TableLayoutPanel1)
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "LOG IN"
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel6.ResumeLayout(False)
        TableLayoutPanel6.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel5.ResumeLayout(False)
        TableLayoutPanel5.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel8.ResumeLayout(False)
        TableLayoutPanel9.ResumeLayout(False)
        ResumeLayout(False)
    End Sub
    Friend WithEvents admintxt As TextBox
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents passtxt As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents adminlog As Button
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents Button1 As Button

End Class
