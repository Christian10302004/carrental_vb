﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel
Imports MySql.Data.MySqlClient

Public Class Accounts

    Private Sub AdminAccounts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        db_connector()
        LoadEmployeeIDs()
        LoadAccounts()
        accountlistview.View = View.Details
        accountlistview.FullRowSelect = True
        AdjustListViewColumns()

    End Sub
    Private Sub AdjustListViewColumns()
        ' Ensure the ListView is populated before adjusting
        If accountlistview.Columns.Count > 0 Then
            Dim totalWidth As Integer = accountlistview.ClientSize.Width
            Dim columnCount As Integer = accountlistview.Columns.Count

            ' Calculate the width for each column based on total width
            Dim columnWidth As Integer = totalWidth \ columnCount

            ' Set each column width
            For Each column As ColumnHeader In accountlistview.Columns
                column.Width = columnWidth
            Next
        End If
    End Sub

    ' Load available employee IDs into ComboBox
    Private Sub LoadEmployeeIDs()
        Try
            Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                conn.Open()
                Dim query As String = "SELECT employeesid FROM employees_info WHERE employeesid NOT IN (SELECT employeeid FROM accounts_info)"
                Dim command As New MySqlCommand(query, conn)
                Dim reader As MySqlDataReader = command.ExecuteReader()

                employeecbb.Items.Clear()

                While reader.Read()
                    employeecbb.Items.Add(reader("employeesid").ToString())
                End While
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading employee IDs: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Load accounts into ListView
    Private Sub LoadAccounts()
        Try
            Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                conn.Open()
                Dim query As String = "SELECT * FROM accounts_info"
                Dim command As New MySqlCommand(query, conn)
                Dim reader As MySqlDataReader = command.ExecuteReader()

                accountlistview.Items.Clear()

                While reader.Read()
                    Dim item As New ListViewItem(reader("accountid").ToString())
                    item.SubItems.Add(reader("employeeid").ToString())
                    item.SubItems.Add(reader("username").ToString())
                    item.SubItems.Add(reader("password").ToString())
                    accountlistview.Items.Add(item)
                End While
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading accounts: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Add new account
    ' Add new account
    Private Sub addbtn1_Click(sender As Object, e As EventArgs) Handles addbtn1.Click
        If ValidateInputs() Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()

                    ' Check if the username already exists
                    Dim checkQuery As String = "SELECT COUNT(*) FROM accounts_info WHERE username = @username"
                    Dim checkCommand As New MySqlCommand(checkQuery, conn)
                    checkCommand.Parameters.AddWithValue("@username", username.Text)
                    Dim count As Integer = Convert.ToInt32(checkCommand.ExecuteScalar())

                    If count > 0 Then
                        MessageBox.Show("The username is already taken. Please choose a different username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If

                    ' Proceed with account creation if username is unique
                    Dim query As String = "INSERT INTO accounts_info (employeeid, username, password) VALUES (@employeeid, @username, @password)"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@employeeid", employeecbb.Text)
                    command.Parameters.AddWithValue("@username", username.Text)
                    command.Parameters.AddWithValue("@password", password.Text)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Account added successfully!")
                    LoadAccounts()
                    LoadEmployeeIDs() ' Refresh employee IDs
                End Using
                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error adding account: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub


    ' Edit selected account
    Private Sub editbtn1_Click(sender As Object, e As EventArgs) Handles editbtn1.Click
        ' Validate inputs in editing mode
        If ValidateInputs(isEditing:=True) AndAlso accountlistview.SelectedItems.Count > 0 Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()

                    ' Get the selected account ID and current username
                    Dim selectedID As String = accountlistview.SelectedItems(0).Text
                    Dim currentUsername As String = accountlistview.SelectedItems(0).SubItems(2).Text

                    ' Check if the new username matches another account (excluding this one)
                    If username.Text <> currentUsername Then
                        Dim checkQuery As String = "SELECT COUNT(*) FROM accounts_info WHERE username = @username AND accountid <> @accountid"
                        Dim checkCommand As New MySqlCommand(checkQuery, conn)
                        checkCommand.Parameters.AddWithValue("@username", username.Text)
                        checkCommand.Parameters.AddWithValue("@accountid", selectedID)

                        Dim count As Integer = Convert.ToInt32(checkCommand.ExecuteScalar())
                        If count > 0 Then
                            MessageBox.Show("The username is already taken. Please choose a different username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            Return
                        End If
                    End If

                    ' Proceed with updating the account (without allowing changes to employeeid)
                    Dim query As String = "UPDATE accounts_info SET username = @username, password = @password WHERE accountid = @accountid"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@username", username.Text)
                    command.Parameters.AddWithValue("@password", password.Text)
                    command.Parameters.AddWithValue("@accountid", selectedID)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Account updated successfully!")
                    LoadAccounts()
                End Using

                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error updating account: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Please select an account to edit and fill out all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Delete selected account
    Private Sub deletebtn1_Click(sender As Object, e As EventArgs) Handles deletebtn1.Click
        If accountlistview.SelectedItems.Count > 0 Then
            Try
                Using conn As New MySqlConnection("server=localhost;user=root;database=carrental;password=")
                    conn.Open()
                    Dim selectedID As String = accountlistview.SelectedItems(0).Text
                    Dim query As String = "DELETE FROM accounts_info WHERE accountid = @accountid"
                    Dim command As New MySqlCommand(query, conn)
                    command.Parameters.AddWithValue("@accountid", selectedID)

                    command.ExecuteNonQuery()
                    MessageBox.Show("Account deleted successfully!")
                    LoadAccounts()
                    LoadEmployeeIDs() ' Refresh employee IDs
                End Using
                ClearInputs()
            Catch ex As Exception
                MessageBox.Show("Error deleting account: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Please select an account to delete.")
        End If

    End Sub

    ' Clear inputs
    Private Sub clearbtn1_Click(sender As Object, e As EventArgs) Handles clearbtn1.Click
        ClearInputs()
    End Sub

    ' Validate inputs

    Private Function ValidateInputs(Optional isEditing As Boolean = False) As Boolean
        ' Ensure employee ID is selected (only for adding new accounts)
        If Not isEditing AndAlso String.IsNullOrWhiteSpace(employeecbb.Text) Then
            MessageBox.Show("Please select an employee ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Ensure username and password are not empty
        If String.IsNullOrWhiteSpace(username.Text) OrElse String.IsNullOrWhiteSpace(password.Text) Then
            MessageBox.Show("Please fill out all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        ' Validate password length
        If password.Text.Length < 3 OrElse password.Text.Length > 8 Then
            MessageBox.Show("Password must be between 3 and 8 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function


    ' Clear input fields
    Private Sub ClearInputs()
        If accountlistview.SelectedItems.Count = 0 Then
            employeecbb.SelectedIndex = -1
        End If
        username.Clear()
        password.Clear()
        addbtn1.Enabled = True
        employeecbb.Enabled = True
    End Sub



    ' Populate fields when an account is selected in ListView
    Private Sub accountlistview_SelectedIndexChanged(sender As Object, e As EventArgs) Handles accountlistview.SelectedIndexChanged
        If accountlistview.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = accountlistview.SelectedItems(0)
            employeecbb.Text = selectedItem.SubItems(1).Text
            username.Text = selectedItem.SubItems(2).Text
            password.Text = selectedItem.SubItems(3).Text
        End If
        addbtn1.Enabled = False
        employeecbb.Enabled = False

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Admin.Show()
        Me.Close()
    End Sub

    Private Sub backbtn_Click(sender As Object, e As EventArgs) Handles backbtn.Click
        AdminLogin.Show()
        Me.Close()
    End Sub
End Class
