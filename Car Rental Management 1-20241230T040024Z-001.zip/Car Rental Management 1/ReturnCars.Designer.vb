﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReturnCars
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel3 = New TableLayoutPanel()
        TableLayoutPanel8 = New TableLayoutPanel()
        Label6 = New Label()
        PictureBox6 = New PictureBox()
        TableLayoutPanel7 = New TableLayoutPanel()
        customerslbl = New Label()
        PictureBox5 = New PictureBox()
        TableLayoutPanel5 = New TableLayoutPanel()
        Label12 = New Label()
        PictureBox2 = New PictureBox()
        TableLayoutPanel4 = New TableLayoutPanel()
        PictureBox3 = New PictureBox()
        Label3 = New Label()
        TableLayoutPanel6 = New TableLayoutPanel()
        TableLayoutPanel9 = New TableLayoutPanel()
        TableLayoutPanel13 = New TableLayoutPanel()
        finesbox = New TextBox()
        Label7 = New Label()
        TableLayoutPanel12 = New TableLayoutPanel()
        delaybox = New TextBox()
        Label5 = New Label()
        TableLayoutPanel11 = New TableLayoutPanel()
        customerbox = New TextBox()
        Label4 = New Label()
        TableLayoutPanel10 = New TableLayoutPanel()
        regnumberbox = New TextBox()
        Label1 = New Label()
        TableLayoutPanel15 = New TableLayoutPanel()
        clearbtn4 = New Button()
        addbtn4 = New Button()
        TableLayoutPanel14 = New TableLayoutPanel()
        totalbox = New TextBox()
        Label8 = New Label()
        TableLayoutPanel19 = New TableLayoutPanel()
        Label11 = New Label()
        remarksbox = New TextBox()
        TableLayoutPanel16 = New TableLayoutPanel()
        TableLayoutPanel18 = New TableLayoutPanel()
        returnedlistview = New ListView()
        ColumnHeader9 = New ColumnHeader()
        ColumnHeader10 = New ColumnHeader()
        ColumnHeader11 = New ColumnHeader()
        ColumnHeader12 = New ColumnHeader()
        ColumnHeader13 = New ColumnHeader()
        ColumnHeader14 = New ColumnHeader()
        ColumnHeader15 = New ColumnHeader()
        ColumnHeader16 = New ColumnHeader()
        Label10 = New Label()
        TableLayoutPanel17 = New TableLayoutPanel()
        Label9 = New Label()
        rentlistview = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        ColumnHeader6 = New ColumnHeader()
        ColumnHeader7 = New ColumnHeader()
        ColumnHeader8 = New ColumnHeader()
        MySqlCommand1 = New MySql.Data.MySqlClient.MySqlCommand()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel8.SuspendLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel7.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel5.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        TableLayoutPanel6.SuspendLayout()
        TableLayoutPanel9.SuspendLayout()
        TableLayoutPanel13.SuspendLayout()
        TableLayoutPanel12.SuspendLayout()
        TableLayoutPanel11.SuspendLayout()
        TableLayoutPanel10.SuspendLayout()
        TableLayoutPanel15.SuspendLayout()
        TableLayoutPanel14.SuspendLayout()
        TableLayoutPanel19.SuspendLayout()
        TableLayoutPanel16.SuspendLayout()
        TableLayoutPanel18.SuspendLayout()
        TableLayoutPanel17.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(TableLayoutPanel2, 0, 0)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel3, 0, 1)
        TableLayoutPanel1.Controls.Add(TableLayoutPanel6, 0, 2)
        TableLayoutPanel1.Dock = DockStyle.Fill
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 3
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 8F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 9F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 83F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.Size = New Size(984, 661)
        TableLayoutPanel1.TabIndex = 2
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.BackColor = Color.White
        TableLayoutPanel2.ColumnCount = 2
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 5F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 95F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 0)
        TableLayoutPanel2.Controls.Add(PictureBox1, 0, 0)
        TableLayoutPanel2.Dock = DockStyle.Fill
        TableLayoutPanel2.Location = New Point(3, 3)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 1
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Size = New Size(978, 46)
        TableLayoutPanel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(51, 12)
        Label2.Name = "Label2"
        Label2.Size = New Size(102, 21)
        Label2.TabIndex = 21
        Label2.Text = "CAR RENTAL"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.Image = My.Resources.Resources.LOGO
        PictureBox1.Location = New Point(12, 6)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(33, 33)
        PictureBox1.TabIndex = 20
        PictureBox1.TabStop = False
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.BackColor = Color.White
        TableLayoutPanel3.ColumnCount = 4
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.Controls.Add(TableLayoutPanel8, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel7, 0, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel5, 1, 0)
        TableLayoutPanel3.Controls.Add(TableLayoutPanel4, 0, 0)
        TableLayoutPanel3.Dock = DockStyle.Fill
        TableLayoutPanel3.Location = New Point(3, 55)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 1
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Size = New Size(978, 53)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' TableLayoutPanel8
        ' 
        TableLayoutPanel8.ColumnCount = 2
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.Controls.Add(Label6, 0, 0)
        TableLayoutPanel8.Controls.Add(PictureBox6, 0, 0)
        TableLayoutPanel8.Dock = DockStyle.Fill
        TableLayoutPanel8.Location = New Point(491, 3)
        TableLayoutPanel8.Name = "TableLayoutPanel8"
        TableLayoutPanel8.RowCount = 1
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel8.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel8.Size = New Size(189, 47)
        TableLayoutPanel8.TabIndex = 3
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(97, 11)
        Label6.Name = "Label6"
        Label6.Size = New Size(59, 25)
        Label6.TabIndex = 23
        Label6.Text = "RENT"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Anchor = AnchorStyles.Right
        PictureBox6.Image = My.Resources.Resources.car__1_
        PictureBox6.Location = New Point(58, 7)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(33, 33)
        PictureBox6.TabIndex = 22
        PictureBox6.TabStop = False
        ' 
        ' TableLayoutPanel7
        ' 
        TableLayoutPanel7.ColumnCount = 2
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel7.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel7.Controls.Add(customerslbl, 0, 0)
        TableLayoutPanel7.Controls.Add(PictureBox5, 0, 0)
        TableLayoutPanel7.Dock = DockStyle.Fill
        TableLayoutPanel7.Location = New Point(296, 3)
        TableLayoutPanel7.Name = "TableLayoutPanel7"
        TableLayoutPanel7.RowCount = 1
        TableLayoutPanel7.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel7.Size = New Size(189, 47)
        TableLayoutPanel7.TabIndex = 2
        ' 
        ' customerslbl
        ' 
        customerslbl.Anchor = AnchorStyles.Left
        customerslbl.AutoSize = True
        customerslbl.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        customerslbl.Location = New Point(59, 11)
        customerslbl.Name = "customerslbl"
        customerslbl.Size = New Size(120, 25)
        customerslbl.TabIndex = 26
        customerslbl.Text = "CUSTOMERS"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Right
        PictureBox5.Image = My.Resources.Resources.rating
        PictureBox5.Location = New Point(20, 7)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(33, 33)
        PictureBox5.TabIndex = 25
        PictureBox5.TabStop = False
        ' 
        ' TableLayoutPanel5
        ' 
        TableLayoutPanel5.ColumnCount = 2
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 30F))
        TableLayoutPanel5.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 70F))
        TableLayoutPanel5.Controls.Add(Label12, 0, 0)
        TableLayoutPanel5.Controls.Add(PictureBox2, 0, 0)
        TableLayoutPanel5.Dock = DockStyle.Fill
        TableLayoutPanel5.Location = New Point(686, 3)
        TableLayoutPanel5.Name = "TableLayoutPanel5"
        TableLayoutPanel5.RowCount = 1
        TableLayoutPanel5.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel5.Size = New Size(289, 47)
        TableLayoutPanel5.TabIndex = 1
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Left
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(89, 11)
        Label12.Name = "Label12"
        Label12.Size = New Size(136, 25)
        Label12.TabIndex = 24
        Label12.Text = "RETURN CARS"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Right
        PictureBox2.Image = My.Resources.Resources._return
        PictureBox2.Location = New Point(50, 7)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(33, 33)
        PictureBox2.TabIndex = 23
        PictureBox2.TabStop = False
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Controls.Add(PictureBox3, 0, 0)
        TableLayoutPanel4.Controls.Add(Label3, 1, 0)
        TableLayoutPanel4.Dock = DockStyle.Fill
        TableLayoutPanel4.Location = New Point(3, 3)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 1
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.Size = New Size(287, 47)
        TableLayoutPanel4.TabIndex = 0
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.Image = My.Resources.Resources.car
        PictureBox3.Location = New Point(107, 7)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(33, 33)
        PictureBox3.TabIndex = 20
        PictureBox3.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Left
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(146, 11)
        Label3.Name = "Label3"
        Label3.Size = New Size(59, 25)
        Label3.TabIndex = 21
        Label3.Text = "CARS"
        ' 
        ' TableLayoutPanel6
        ' 
        TableLayoutPanel6.ColumnCount = 2
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel6.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 80F))
        TableLayoutPanel6.Controls.Add(TableLayoutPanel9, 0, 0)
        TableLayoutPanel6.Controls.Add(TableLayoutPanel16, 1, 0)
        TableLayoutPanel6.Dock = DockStyle.Fill
        TableLayoutPanel6.Location = New Point(3, 114)
        TableLayoutPanel6.Name = "TableLayoutPanel6"
        TableLayoutPanel6.RowCount = 1
        TableLayoutPanel6.RowStyles.Add(New RowStyle(SizeType.Percent, 100F))
        TableLayoutPanel6.Size = New Size(978, 544)
        TableLayoutPanel6.TabIndex = 2
        ' 
        ' TableLayoutPanel9
        ' 
        TableLayoutPanel9.ColumnCount = 1
        TableLayoutPanel9.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel9.Controls.Add(TableLayoutPanel13, 0, 3)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel12, 0, 2)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel11, 0, 1)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel10, 0, 0)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel15, 0, 6)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel14, 0, 5)
        TableLayoutPanel9.Controls.Add(TableLayoutPanel19, 0, 4)
        TableLayoutPanel9.Dock = DockStyle.Fill
        TableLayoutPanel9.Location = New Point(3, 3)
        TableLayoutPanel9.Name = "TableLayoutPanel9"
        TableLayoutPanel9.RowCount = 7
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.RowStyles.Add(New RowStyle(SizeType.Percent, 14.2857141F))
        TableLayoutPanel9.Size = New Size(189, 538)
        TableLayoutPanel9.TabIndex = 0
        ' 
        ' TableLayoutPanel13
        ' 
        TableLayoutPanel13.BackColor = Color.White
        TableLayoutPanel13.ColumnCount = 1
        TableLayoutPanel13.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel13.Controls.Add(finesbox, 0, 1)
        TableLayoutPanel13.Controls.Add(Label7, 0, 0)
        TableLayoutPanel13.Dock = DockStyle.Fill
        TableLayoutPanel13.Location = New Point(3, 231)
        TableLayoutPanel13.Name = "TableLayoutPanel13"
        TableLayoutPanel13.RowCount = 2
        TableLayoutPanel13.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel13.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel13.Size = New Size(183, 70)
        TableLayoutPanel13.TabIndex = 3
        ' 
        ' finesbox
        ' 
        finesbox.Anchor = AnchorStyles.Top
        finesbox.Location = New Point(26, 38)
        finesbox.Name = "finesbox"
        finesbox.Size = New Size(130, 23)
        finesbox.TabIndex = 3
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Bottom
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(60, 10)
        Label7.Name = "Label7"
        Label7.Size = New Size(63, 25)
        Label7.TabIndex = 2
        Label7.Text = "FINES"
        ' 
        ' TableLayoutPanel12
        ' 
        TableLayoutPanel12.BackColor = Color.White
        TableLayoutPanel12.ColumnCount = 1
        TableLayoutPanel12.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.Controls.Add(delaybox, 0, 1)
        TableLayoutPanel12.Controls.Add(Label5, 0, 0)
        TableLayoutPanel12.Dock = DockStyle.Fill
        TableLayoutPanel12.Location = New Point(3, 155)
        TableLayoutPanel12.Name = "TableLayoutPanel12"
        TableLayoutPanel12.RowCount = 2
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel12.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel12.Size = New Size(183, 70)
        TableLayoutPanel12.TabIndex = 2
        ' 
        ' delaybox
        ' 
        delaybox.Anchor = AnchorStyles.Top
        delaybox.Location = New Point(26, 38)
        delaybox.Name = "delaybox"
        delaybox.Size = New Size(130, 23)
        delaybox.TabIndex = 3
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Bottom
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(57, 10)
        Label5.Name = "Label5"
        Label5.Size = New Size(68, 25)
        Label5.TabIndex = 2
        Label5.Text = "DELAY"
        ' 
        ' TableLayoutPanel11
        ' 
        TableLayoutPanel11.BackColor = Color.White
        TableLayoutPanel11.ColumnCount = 1
        TableLayoutPanel11.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Controls.Add(customerbox, 0, 1)
        TableLayoutPanel11.Controls.Add(Label4, 0, 0)
        TableLayoutPanel11.Dock = DockStyle.Fill
        TableLayoutPanel11.Location = New Point(3, 79)
        TableLayoutPanel11.Name = "TableLayoutPanel11"
        TableLayoutPanel11.RowCount = 2
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel11.Size = New Size(183, 70)
        TableLayoutPanel11.TabIndex = 1
        ' 
        ' customerbox
        ' 
        customerbox.Anchor = AnchorStyles.Top
        customerbox.Enabled = False
        customerbox.Location = New Point(26, 38)
        customerbox.Name = "customerbox"
        customerbox.Size = New Size(130, 23)
        customerbox.TabIndex = 3
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(6, 10)
        Label4.Name = "Label4"
        Label4.Size = New Size(171, 25)
        Label4.TabIndex = 2
        Label4.Text = "CUSTOMER NAME"
        ' 
        ' TableLayoutPanel10
        ' 
        TableLayoutPanel10.BackColor = Color.White
        TableLayoutPanel10.ColumnCount = 1
        TableLayoutPanel10.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Controls.Add(regnumberbox, 0, 1)
        TableLayoutPanel10.Controls.Add(Label1, 0, 0)
        TableLayoutPanel10.Dock = DockStyle.Fill
        TableLayoutPanel10.Location = New Point(3, 3)
        TableLayoutPanel10.Name = "TableLayoutPanel10"
        TableLayoutPanel10.RowCount = 2
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel10.Size = New Size(183, 70)
        TableLayoutPanel10.TabIndex = 0
        ' 
        ' regnumberbox
        ' 
        regnumberbox.Anchor = AnchorStyles.Top
        regnumberbox.Enabled = False
        regnumberbox.Location = New Point(26, 38)
        regnumberbox.Name = "regnumberbox"
        regnumberbox.Size = New Size(130, 23)
        regnumberbox.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Bottom
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(26, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(131, 25)
        Label1.TabIndex = 1
        Label1.Text = "REG NUMBER"
        ' 
        ' TableLayoutPanel15
        ' 
        TableLayoutPanel15.BackColor = Color.White
        TableLayoutPanel15.ColumnCount = 1
        TableLayoutPanel15.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Controls.Add(clearbtn4, 0, 1)
        TableLayoutPanel15.Controls.Add(addbtn4, 0, 0)
        TableLayoutPanel15.Dock = DockStyle.Fill
        TableLayoutPanel15.Location = New Point(3, 459)
        TableLayoutPanel15.Name = "TableLayoutPanel15"
        TableLayoutPanel15.RowCount = 2
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel15.Size = New Size(183, 76)
        TableLayoutPanel15.TabIndex = 5
        ' 
        ' clearbtn4
        ' 
        clearbtn4.Anchor = AnchorStyles.None
        clearbtn4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        clearbtn4.Location = New Point(41, 41)
        clearbtn4.Name = "clearbtn4"
        clearbtn4.Size = New Size(100, 32)
        clearbtn4.TabIndex = 1
        clearbtn4.Text = "CLEAR"
        clearbtn4.UseVisualStyleBackColor = True
        ' 
        ' addbtn4
        ' 
        addbtn4.Anchor = AnchorStyles.None
        addbtn4.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        addbtn4.Location = New Point(41, 3)
        addbtn4.Name = "addbtn4"
        addbtn4.Size = New Size(100, 32)
        addbtn4.TabIndex = 0
        addbtn4.Text = "ADD"
        addbtn4.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel14
        ' 
        TableLayoutPanel14.BackColor = Color.White
        TableLayoutPanel14.ColumnCount = 1
        TableLayoutPanel14.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Controls.Add(totalbox, 0, 1)
        TableLayoutPanel14.Controls.Add(Label8, 0, 0)
        TableLayoutPanel14.Dock = DockStyle.Fill
        TableLayoutPanel14.Location = New Point(3, 383)
        TableLayoutPanel14.Name = "TableLayoutPanel14"
        TableLayoutPanel14.RowCount = 2
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel14.Size = New Size(183, 70)
        TableLayoutPanel14.TabIndex = 4
        ' 
        ' totalbox
        ' 
        totalbox.Anchor = AnchorStyles.Top
        totalbox.Location = New Point(26, 38)
        totalbox.Name = "totalbox"
        totalbox.Size = New Size(130, 23)
        totalbox.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Bottom
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(59, 10)
        Label8.Name = "Label8"
        Label8.Size = New Size(65, 25)
        Label8.TabIndex = 2
        Label8.Text = "TOTAL"
        ' 
        ' TableLayoutPanel19
        ' 
        TableLayoutPanel19.BackColor = Color.White
        TableLayoutPanel19.ColumnCount = 1
        TableLayoutPanel19.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel19.Controls.Add(Label11, 0, 0)
        TableLayoutPanel19.Controls.Add(remarksbox, 0, 1)
        TableLayoutPanel19.Dock = DockStyle.Fill
        TableLayoutPanel19.Location = New Point(3, 307)
        TableLayoutPanel19.Name = "TableLayoutPanel19"
        TableLayoutPanel19.RowCount = 2
        TableLayoutPanel19.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel19.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel19.Size = New Size(183, 70)
        TableLayoutPanel19.TabIndex = 6
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Bottom
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(42, 10)
        Label11.Name = "Label11"
        Label11.Size = New Size(99, 25)
        Label11.TabIndex = 3
        Label11.Text = "REMARKS"
        ' 
        ' remarksbox
        ' 
        remarksbox.Anchor = AnchorStyles.Top
        remarksbox.Location = New Point(26, 38)
        remarksbox.Name = "remarksbox"
        remarksbox.Size = New Size(130, 23)
        remarksbox.TabIndex = 4
        ' 
        ' TableLayoutPanel16
        ' 
        TableLayoutPanel16.ColumnCount = 1
        TableLayoutPanel16.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Controls.Add(TableLayoutPanel18, 0, 1)
        TableLayoutPanel16.Controls.Add(TableLayoutPanel17, 0, 0)
        TableLayoutPanel16.Dock = DockStyle.Fill
        TableLayoutPanel16.Location = New Point(198, 3)
        TableLayoutPanel16.Name = "TableLayoutPanel16"
        TableLayoutPanel16.RowCount = 2
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel16.Size = New Size(777, 538)
        TableLayoutPanel16.TabIndex = 1
        ' 
        ' TableLayoutPanel18
        ' 
        TableLayoutPanel18.BackColor = Color.White
        TableLayoutPanel18.ColumnCount = 1
        TableLayoutPanel18.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel18.Controls.Add(returnedlistview, 0, 1)
        TableLayoutPanel18.Controls.Add(Label10, 0, 0)
        TableLayoutPanel18.Dock = DockStyle.Fill
        TableLayoutPanel18.Location = New Point(3, 272)
        TableLayoutPanel18.Name = "TableLayoutPanel18"
        TableLayoutPanel18.RowCount = 2
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 15F))
        TableLayoutPanel18.RowStyles.Add(New RowStyle(SizeType.Percent, 85F))
        TableLayoutPanel18.Size = New Size(771, 263)
        TableLayoutPanel18.TabIndex = 1
        ' 
        ' returnedlistview
        ' 
        returnedlistview.Columns.AddRange(New ColumnHeader() {ColumnHeader9, ColumnHeader10, ColumnHeader11, ColumnHeader12, ColumnHeader13, ColumnHeader14, ColumnHeader15, ColumnHeader16})
        returnedlistview.Dock = DockStyle.Fill
        returnedlistview.Font = New Font("Segoe UI", 11F)
        returnedlistview.GridLines = True
        returnedlistview.Location = New Point(3, 42)
        returnedlistview.Name = "returnedlistview"
        returnedlistview.Size = New Size(765, 218)
        returnedlistview.TabIndex = 2
        returnedlistview.UseCompatibleStateImageBehavior = False
        returnedlistview.View = View.Details
        ' 
        ' ColumnHeader9
        ' 
        ColumnHeader9.Text = "RETURN ID"
        ColumnHeader9.Width = 80
        ' 
        ' ColumnHeader10
        ' 
        ColumnHeader10.Text = "REG NUMBER"
        ColumnHeader10.TextAlign = HorizontalAlignment.Center
        ColumnHeader10.Width = 100
        ' 
        ' ColumnHeader11
        ' 
        ColumnHeader11.Text = "CUSTOMER NAME"
        ColumnHeader11.TextAlign = HorizontalAlignment.Center
        ColumnHeader11.Width = 120
        ' 
        ' ColumnHeader12
        ' 
        ColumnHeader12.Text = "RETURN DATE"
        ColumnHeader12.TextAlign = HorizontalAlignment.Center
        ColumnHeader12.Width = 120
        ' 
        ' ColumnHeader13
        ' 
        ColumnHeader13.Text = "DELAY"
        ColumnHeader13.TextAlign = HorizontalAlignment.Center
        ColumnHeader13.Width = 80
        ' 
        ' ColumnHeader14
        ' 
        ColumnHeader14.Text = "FINES"
        ColumnHeader14.TextAlign = HorizontalAlignment.Center
        ColumnHeader14.Width = 80
        ' 
        ' ColumnHeader15
        ' 
        ColumnHeader15.Text = "REMARKS"
        ColumnHeader15.TextAlign = HorizontalAlignment.Center
        ColumnHeader15.Width = 80
        ' 
        ' ColumnHeader16
        ' 
        ColumnHeader16.Text = "TOTAL"
        ColumnHeader16.TextAlign = HorizontalAlignment.Center
        ColumnHeader16.Width = 100
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.None
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(306, 7)
        Label10.Name = "Label10"
        Label10.Size = New Size(159, 25)
        Label10.TabIndex = 1
        Label10.Text = "RETURNED DATE"
        ' 
        ' TableLayoutPanel17
        ' 
        TableLayoutPanel17.BackColor = Color.White
        TableLayoutPanel17.ColumnCount = 1
        TableLayoutPanel17.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel17.Controls.Add(Label9, 0, 0)
        TableLayoutPanel17.Controls.Add(rentlistview, 0, 1)
        TableLayoutPanel17.Dock = DockStyle.Fill
        TableLayoutPanel17.Location = New Point(3, 3)
        TableLayoutPanel17.Name = "TableLayoutPanel17"
        TableLayoutPanel17.RowCount = 2
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 15F))
        TableLayoutPanel17.RowStyles.Add(New RowStyle(SizeType.Percent, 85F))
        TableLayoutPanel17.Size = New Size(771, 263)
        TableLayoutPanel17.TabIndex = 0
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.None
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(330, 7)
        Label9.Name = "Label9"
        Label9.Size = New Size(110, 25)
        Label9.TabIndex = 0
        Label9.Text = "RENT DATE"
        ' 
        ' rentlistview
        ' 
        rentlistview.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5, ColumnHeader6, ColumnHeader7, ColumnHeader8})
        rentlistview.Dock = DockStyle.Fill
        rentlistview.Font = New Font("Segoe UI", 11F)
        rentlistview.GridLines = True
        rentlistview.Location = New Point(3, 42)
        rentlistview.Name = "rentlistview"
        rentlistview.Size = New Size(765, 218)
        rentlistview.TabIndex = 1
        rentlistview.UseCompatibleStateImageBehavior = False
        rentlistview.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "RENT ID"
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "REG NUMBER"
        ColumnHeader2.Width = 100
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "CUSTOMER ID"
        ColumnHeader3.TextAlign = HorizontalAlignment.Center
        ColumnHeader3.Width = 100
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "CUSTOMER NAME"
        ColumnHeader4.TextAlign = HorizontalAlignment.Center
        ColumnHeader4.Width = 120
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "RENT DATE"
        ColumnHeader5.TextAlign = HorizontalAlignment.Center
        ColumnHeader5.Width = 100
        ' 
        ' ColumnHeader6
        ' 
        ColumnHeader6.Text = "RETURN DATE"
        ColumnHeader6.TextAlign = HorizontalAlignment.Center
        ColumnHeader6.Width = 100
        ' 
        ' ColumnHeader7
        ' 
        ColumnHeader7.Text = "ADDRESS"
        ColumnHeader7.TextAlign = HorizontalAlignment.Center
        ColumnHeader7.Width = 80
        ' 
        ' ColumnHeader8
        ' 
        ColumnHeader8.Text = "FEES"
        ColumnHeader8.TextAlign = HorizontalAlignment.Center
        ' 
        ' MySqlCommand1
        ' 
        MySqlCommand1.CacheAge = 0
        MySqlCommand1.Connection = Nothing
        MySqlCommand1.EnableCaching = False
        MySqlCommand1.Transaction = Nothing
        ' 
        ' ReturnCars
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(984, 661)
        Controls.Add(TableLayoutPanel1)
        Name = "ReturnCars"
        Text = "ReturnCars"
        WindowState = FormWindowState.Maximized
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel8.ResumeLayout(False)
        TableLayoutPanel8.PerformLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel7.ResumeLayout(False)
        TableLayoutPanel7.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel5.ResumeLayout(False)
        TableLayoutPanel5.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        TableLayoutPanel6.ResumeLayout(False)
        TableLayoutPanel9.ResumeLayout(False)
        TableLayoutPanel13.ResumeLayout(False)
        TableLayoutPanel13.PerformLayout()
        TableLayoutPanel12.ResumeLayout(False)
        TableLayoutPanel12.PerformLayout()
        TableLayoutPanel11.ResumeLayout(False)
        TableLayoutPanel11.PerformLayout()
        TableLayoutPanel10.ResumeLayout(False)
        TableLayoutPanel10.PerformLayout()
        TableLayoutPanel15.ResumeLayout(False)
        TableLayoutPanel14.ResumeLayout(False)
        TableLayoutPanel14.PerformLayout()
        TableLayoutPanel19.ResumeLayout(False)
        TableLayoutPanel19.PerformLayout()
        TableLayoutPanel16.ResumeLayout(False)
        TableLayoutPanel18.ResumeLayout(False)
        TableLayoutPanel18.PerformLayout()
        TableLayoutPanel17.ResumeLayout(False)
        TableLayoutPanel17.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents customerslbl As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label12 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel15 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel14 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel13 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents regnumberbox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents addbtn4 As Button
    Friend WithEvents clearbtn4 As Button
    Friend WithEvents totalbox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents finesbox As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents delaybox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents customerbox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents MySqlCommand1 As MySql.Data.MySqlClient.MySqlCommand
    Friend WithEvents TableLayoutPanel16 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents returnedlistview As ListView
    Friend WithEvents rentlistview As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents ColumnHeader7 As ColumnHeader
    Friend WithEvents ColumnHeader8 As ColumnHeader
    Friend WithEvents ColumnHeader9 As ColumnHeader
    Friend WithEvents ColumnHeader10 As ColumnHeader
    Friend WithEvents ColumnHeader11 As ColumnHeader
    Friend WithEvents ColumnHeader12 As ColumnHeader
    Friend WithEvents ColumnHeader13 As ColumnHeader
    Friend WithEvents ColumnHeader14 As ColumnHeader
    Friend WithEvents ColumnHeader16 As ColumnHeader
    Friend WithEvents TableLayoutPanel19 As TableLayoutPanel
    Friend WithEvents Label11 As Label
    Friend WithEvents remarksbox As TextBox
    Friend WithEvents ColumnHeader15 As ColumnHeader
End Class
