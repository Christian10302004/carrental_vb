﻿Public Class editor
    Private Sub TableLayoutPanel2_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub TableLayoutPanel18_Paint(sender As Object, e As PaintEventArgs)

    End Sub
End Class